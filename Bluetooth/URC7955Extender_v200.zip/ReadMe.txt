THE ALTERNATIVES FOR RMIR BLUETOOTH CONNECTION.

RMIR v2.07 includes a new interface, JP2BT, to connect RMIR by Bluetooth to remotes that support the UEI Bluetooth "One for All Setup" phone app.  At present two such remotes are supported, the URC-7980 and URC-7955.  From build 6 onward there are three ways to connect this interface to the remote, each of which requires something additional as follows.

1.   The original means of connection, present in all builds of RMIR v2.07, is to use the Bluegiga BLED112 Bluetooth Low Energy Dongle by Silicon Labs:

https://www.silabs.com/products/wireless/bluetooth/bluetooth-low-energy-modules/bled112-bluetooth-smart-dongle

available from them for $10.45 or in Europe from RS for �8.52 at

https://uk.rs-online.com/web/p/bluetooth-adapters/8077742/#

It is also necessary to install version 1.00 of the Bluetooth extender for the remote concerned, but no interface cable is required as this is installed with the dongle itself through the Bluetooth facilities that already work without the extender.  This is a one-off process and the extender takes up no room in the user memory of the remote.  This means of connection is supported by Windows, Linux and Mac OS X.

2.  Windows 10 users can now connect through the Bluetooth support of that OS. If the PC has Bluetooth hardware built in, as most laptops do, no further hardware is required.  Otherwise a standard Bluetooth dongle will be required, which works in conjunction with the Microsoft Bluetooth software stack of Windows 10.  This access method requires version 2.00 of the Bluetooth extender, which needs a JP1.x cable for its installation as the Microsoft stack will not connect at all without this extender being present.  There is some evidence that not all Windows 10 machines fully support this means of connection.  The only way to find out is to try it.  The extender also provides facilities for uninstalling, if this is desired, but its presence is essentially invisible if the Bluetooth features of the remote are not being used.

3.  The Bluetooth support in Windows versions earlier than Windows 10, even if present, is unable to connect to these remotes but there is installable Bluetooth support available from Blue Soleil, see:

http://www.bluesoleil.com

The current version, Blue Soleil 10, costs $28.  Blue Soleil claims that this supports all Windows versions from Windows XP onward but there is evidence on the web that not all PCs can run it.  Again, I know of no method other than trying it.  Blue Soleil will work either with Bluetooth hardware built in to the PC or with a separate standard Bluetooth dongle, but you need to be aware that these remotes need Bluetooth 4 or later.  I have RMIR running with Blue Soleil 10 on my Windows 8.1 machine with its built-in Bluetooth hardware.  That is all I can vouch for.  RMIR with Blue Soleil requires only version 1.00 of the Bluetooth extender which, as with method 1 above, is installed via the Bluetooth facilities that work without the extender, so no JP1.x cable is required.  This therefore provides an alternative to needing a JP1.x cable for Windows 10 users that do not already have such a cable.


THE EXTENDERS.

Version 2.00 of the Bluetooth extender includes the features of version 1.00, so version 2.00 can be used even if only version 1.00 is needed.  However, version 2.00 has no advantage over version 1.00 for access methods that only need version 1.00.  Essentially, version 2.00 is needed for access methods that use the Microsoft Bluetooth stack of Windows 10.  The Bluetooth support in these remotes is, in one minor respect, not strictly conformant to the Bluetooth specification.  Both the Texas Instruments stack used by the Bluegiga dongle of method 1 above, and the Blue Soleil stack of method 3, ignore this conformance failure.  The Microsoft stack is fussier and requires this strict conformance.  Version 2.00 of the extender fixes this conformance issue and so permits use with the Microsoft stack.  The issue fixed by both extender versions is that as supplied, these remotes support downloading via Bluetooth but not uploading, as the functionality required in the remote for uploading has been only partly implemented by UEI.  This lies outside the scope of the Bluetooth specification so is not a conformance issue.  Both extenders fix this partial implementation, providing both upload and download capabilities and so allowing full support of all RMIR features.  

Although referred to as extenders, these are actually extender installers.  They are used once to install (or alternatively to uninstall) the extender proper and are then deleted, so they take up none of the memory available for user setup.  They remain permanently installed until actively uninstalled, and so survive a change of batteries and even a factory reset.  As mentioned above, version 2.00 includes the features of version 1.00.  Version 2.00 can be installed in a remote either with or without version 1.00 present.  The uninstaller of version 2.00 will do nothing if only version 1.00 is installed, and will uninstall both versions if used in a remote where version 2.00 was installed on top of version 1.00.  Separate versions of each extender are available for the URC7980 and URC7955.  This ReadMe applies to both versions and both remotes.  The installation process will not allow you to install an extender for the wrong remote.


INSTALLATION.

It is advisable first to download the current setup with RMIR and to save it as a .rmir file. If installing version 1.00, you can download via Bluetooth.  For version 2.00, you can use the cable that you will need in any case for the installation.

Version 1.00 is provided as a .hex file named URCnnnnExtender_v100.hex (where nnnn is 7980 or 7955 as appropriate), version 2.00 as a .rmir file named URCnnnnExtender_v200.rmir.  Version 1.00 is loaded by Bluetooth into the setup currently present in the remote while version 2.00, like the upload of any other .rmir file, replaces the existing setup.  This difference means that for version 1.00 there are prerequisites to be checked about the current setup.  These are that (i) the "Memory usage" progress bar shows that there is at least 1760 bytes of free memory, (ii) the "Key Moves" tab shows that the setup does not include any key moves, (iii) you do not have any macro or learned signal on the Power or Stop buttons that are used during the installation.  If any of these are not satisfied, you need to do a factory reset before loading the installer.  To do this, press and hold Magic until the LED is steadily lit, then enter 981.  Wait for the 4 flashes that confirms the factory reset is complete.

Installing the extender is a three-stage process, (a) loading the file that is the extender installer, (b) running the installer to install or uninstall the extender, (c) deleting the installer.  Only step (a) differs between versions 1.00 and 2.00.  Here are the details.

(a1) Loading the extender installer (version 1.00)

You can ONLY load version 1.00 via Bluetooth.  It cannot be done with a cable.  You can load it either after a download, or if you have previously verified the prerequisites then straight after connecting, without repeating the download.  Select the File > Install extender... menu item and navigate to the folder containing the appropriate .hex file.  Select it and press Open.  The installation should commence and show its progress in the progress bar as "INSTALLING: xx" where xx is a percentage.  When complete, a pop-up message "Installation succeeded" should appear.

You can further verify the installation by now doing a download.  The Devices tab should then show 9 new entries with Device Type = TV and Setup Codes 1800 to 1804 and 1806-1809.  (It is intentional that there is no 1805).  Then disconnect the Bluetooth connection.  To finish the loading process, you need to set the TV device to TV/1800 on the remote itself.  Press Magic till the LED is steadily lit, then repeatedly press Devices if necessary until it is the TV LED that is lit.  Then enter 1800.  The LED should flash twice on success.


(a2) Loading the extender installer (version 2.00)

You load version 2.00 with a JP1.x cable like any other .rmir file, with the Upload button on the toolbar or the Remote > Upload to Remote menu item.  You will see that the setup consists of one setup code, TV/1800, on the General tab and 14 devices with type TV and setup codes 1800-1813 on the Devices tab.  Do not change anything, it is deliberate that only one of these 14 devices is actually assigned on the General tab.  They are nevertheless all used during the installation process.


(b) Running the installer to install or uninstall the extender

First select the TV device.  To test that the installer is now successfully selected, press a digit key (see note 1 below).  The LED should give a brief flicker.  This performs no action, but it is a safe way to test that all is well so far.  Now press Power to install or Stop to uninstall the extender.  Observe the flashes of the TV LED for a result status:

One long flash of about a second followed by one or two shorter (200ms) flashes for a successful install/uninstall
Three short (200ms) flashes if the extender is already installed or uninstalled (so no action took place)
Four short flashes if the battery is too low to perform the installation.

Finally you need to disconnect and reconnect RMIR for it to recognise that the remote now accepts uploads.  If installing version 2.00 you need to ensure that the remote re-boots before reconnecting, to activate the conformance fix.  The easiest way is to remove and reinsert the batteries.

Here are some additional notes:

1.  As well as the Power and Stop keys, the digit keys are also active.  They do nothing, but the TV LED gives a brief flash (normal flashes are about 200ms, these are just short flickers).  This is useful to check that the extender is properly installed before pressing Power or Stop.  If the TV LED is already lit, such as after pressing the Devices button, pressing a digit key turns it off.  Always have the LED off before pressing Power or Stop, as otherwise the number of flashes is unclear.

2.  If pressing the Power or Stop button gives a brief flicker, like the digit keys, rather than 2 to 4 flashes then there was an error in loading the installer and no action has occurred.

3.  The TV/180x devices other than TV/1800 have no effect if set instead of TV/1800 as the TV device.  The digit buttons will give a brief flash, Power and Stop will do nothing.

4.  RMIR checks that the extender installer you are loading is the correct one for your remote, so there is no danger of installing the wrong one.


(c) Deleting the installer

Both installers take up a lot of space in user memory, so it is wise to delete the installer after use.  The simplest way is just to upload the original setup that you saved as a .rmir file.  You can use Bluetooth for this, as uploading will now work.  Alternatively you can do a factory reset and create a fresh installation.  As mentioned above, a factory reset does not remove the extender.  If you installed version 1.00 and did not save your original setup, you can instead use RMIR to delete the 9 device upgrades that form the installer.

If you ever want to remove the extender, re-load the installer and follow the instructions in (b) for uninstalling.  Remember that you will not be able to remove the installer afterwards other than by a factory reset, unless you also have a JP1.x cable and use that interface to the remote, as you have removed the ability of RMIR to perform Bluetooth uploads to the remote.

Graham Dixon
March 28, 2019





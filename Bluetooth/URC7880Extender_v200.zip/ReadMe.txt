THE ALTERNATIVES FOR RMIR BLUETOOTH CONNECTION.

RMIR v2.07 includes a new interface, JP2BT, to connect RMIR by Bluetooth to remotes that support the UEI Bluetooth "One for All Setup" phone app.  At present three such remotes are supported, the URC-7980, URC-7955 and URC-7880.  From build 6 of RMIR v2.07 onward there are three ways to connect this interface to the remote, each of which requires something additional as follows.

1.   The original means of connection, present in all builds of RMIR v2.07, is to use the Bluegiga BLED112 Bluetooth Low Energy Dongle by Silicon Labs:

https://www.silabs.com/products/wireless/bluetooth/bluetooth-low-energy-modules/bled112-bluetooth-smart-dongle

available from them for $10.45 or in Europe from RS for �8.52 at

https://uk.rs-online.com/web/p/bluetooth-adapters/8077742/#

It is also necessary to install version 1.00 of the Bluetooth extender for the remote concerned, but no interface cable is required as this is installed with the dongle itself through the Bluetooth facilities that already work without the extender.  This is a one-off process and the extender takes up no room in the user memory of the remote.  This means of connection is supported by Windows, Linux and Mac OS X.

2.  Windows 10 users can now connect through the Bluetooth support of that OS. If the PC has Bluetooth hardware built in, as most laptops do, no further hardware is required.  Otherwise a standard Bluetooth dongle will be required, which works in conjunction with the Microsoft Bluetooth software stack of Windows 10.  This access method requires version 2.00 of the Bluetooth extender, which needs a JP1.x cable for its installation as the Microsoft stack will not connect at all without this extender being present.  There is some evidence that not all Windows 10 machines fully support this means of connection.  The only way to find out is to try it.  The extender also provides facilities for uninstalling, if this is desired, but its presence is essentially invisible if the Bluetooth features of the remote are not being used.

3.  The Bluetooth support in Windows versions earlier than Windows 10, even if present, is unable to connect to these remotes but there is installable Bluetooth support available from Blue Soleil, see:

http://www.bluesoleil.com

The current version, Blue Soleil 10, costs $28.  Blue Soleil claims that this supports all Windows versions from Windows XP onward but there is evidence on the web that not all PCs can run it.  Again, I know of no method other than trying it.  Blue Soleil will work either with Bluetooth hardware built in to the PC or with a separate standard Bluetooth dongle, but you need to be aware that these remotes need Bluetooth 4 or later.  I have RMIR running with Blue Soleil 10 on my Windows 8.1 machine with its built-in Bluetooth hardware.  That is all I can vouch for.  RMIR with Blue Soleil requires only version 1.00 of the Bluetooth extender which, as with method 1 above, is installed via the Bluetooth facilities that work without the extender, so no JP1.x cable is required.  This therefore provides an alternative to needing a JP1.x cable for Windows 10 users that do not already have such a cable.


THE EXTENDERS.

Version 2.00 of the Bluetooth extender includes the features of version 1.00, so version 2.00 can be used even if only version 1.00 is needed.  However, version 2.00 has no advantage over version 1.00 for access methods that only need version 1.00.  Essentially, version 2.00 is needed for access methods that use the Microsoft Bluetooth stack of Windows 10.  The Bluetooth support in these remotes is, in one minor respect, not strictly conformant to the Bluetooth specification.  Both the Texas Instruments stack used by the Bluegiga dongle of method 1 above, and the Blue Soleil stack of method 3, ignore this conformance failure.  The Microsoft stack is fussier and requires this strict conformance.  Version 2.00 of the extender fixes this conformance issue and so permits use with the Microsoft stack.  The issue fixed by both extender versions is that as supplied, these remotes support downloading via Bluetooth but not uploading, as the functionality required in the remote for uploading has been only partly implemented by UEI.  This lies outside the scope of the Bluetooth specification so is not a conformance issue.  Both extenders fix this partial implementation, providing both upload and download capabilities and so allowing full support of all RMIR features.  

Although referred to as extenders, these are actually extender installers.  They are used once to install (or alternatively to uninstall) the extender proper and are then deleted, so they take up none of the memory available for user setup.  They remain permanently installed until actively uninstalled, and so survive a change of batteries and even a factory reset.  As mentioned above, version 2.00 includes the features of version 1.00.  Version 2.00 can be installed in a remote either with or without version 1.00 present.  The uninstaller of version 2.00 will do nothing if only version 1.00 is installed, and will uninstall both versions if used in a remote where version 2.00 was installed on top of version 1.00.  Separate versions of each extender are available for each of the three remotes.  The installation process will not allow you to install an extender for the wrong remote.

The information given above covers both extender versions and all three remotes.  The installation instructions which follow are, however, specific to version 2.00 for the URC-7880.  This is because the data area of the URC-7880 is only half the size of that of the URC-7980 and URC-7955 and the installation process has had to be split into more stages to fit in this reduced size.  See the ReadMe included with other versions of the extender for the installation instructions for those versions. 


INSTALLATION OF EXTENDER V2.00 FOR THE URC-7880.

It is advisable first to download the current setup with RMIR and to save it as a .rmir file, using the cable that you will need in any case for the installation.

The extender is provided as a set of four .rmir files, with names of the form URC7880Extender_v200x_y.rmir where "x" is either "a" or "b" and "y" is either "in" or "out".  The two "in" files are used for installation and the two "out" files for uninstallation if that is ever required.  When installing the extender the "a_in" file is used first, followed by the "b_in" file.  If uninstalling it, the "b_out" file is used first to uninstall the "b" part of the extender, then the "a_out" file is used to uninstall the "a" part.  In more detail the "a" part of extender v2.00 consists of extender v1.00 together with additional code that is active only when the "b" part is also installed.  So the "a" part is complete in itself but the "b" part is not, which is why the two parts need to be uninstalled in the reverse order to their installation.

Each .rmir file is used in the same way.  It is loaded into the remote with a JP1.x cable like any other .rmir file, with the Upload button on the toolbar or the Remote > Upload to Remote menu item.  For any of the four files, you will see that the setup consists of one setup code, TV/1800, on the General tab and seven devices with type TV and setup codes in the range 1800-1809 on the Devices tab.  Do not change anything, it is deliberate that only one of these seven devices is actually assigned on the General tab.  They are nevertheless all used during the installation process.

After uploading the file, disconnect the cable from the remote.  Before running its step of the process, first test that this installer step has loaded correctly by pressing a digit key (see note 1 below).  The LED should give a brief flicker.  If nothing happens, check that the TV device is selected, which should happen automatically after the upload.  Pressing a digit key performs no action, but it is a safe way to test that all is well so far.  Now press Power (if installing the extender) or Stop (if uninstalling it).  Observe the flashes of the TV LED for a result status:

* Two short flashes signify a successful install/uninstall step.  The second flash is about 200ms, the first will be a little longer.
* Three short (200ms) flashes signify the step is already installed/uninstalled (so no action took place).
* Four short flashes means the battery is too low to perform the process.

If you are not sure of the result, press the button again.  Three short flashes will confirm that the step was successful.  If this was a "b" step (the second step if installing, the first if uninstalling) NOW REMOVE ONE OF THE BATTERIES, WAIT AROUND 15 SECONDS AND THEN REPLACE IT.  This is needed to force the remote to re-boot, which is needed to complete a step "b" but not a step "a".  The wait makes sure any stored charge disperses.  The re-boot takes around 10 seconds after replacing the battery and the TV LED should flash twice when it is complete.

To install the extender, follow the above steps first for the "a_in" file then for the "b_in" file.  To uninstall it, follow the steps first for the "b_out" file then for the "a_out" file.  Finally use RMIR again to upload the setup you saved before starting the process.  If you do not have a saved setup then do a factory reset by pressing and holding Magic until the LED is steadily lit, then entering 981.  Wait for the 4 flashes that confirms the factory reset is complete.  

The extender is now installed.  To use the remote with Bluetooth, open RMIR and select the Remote > Interface > JP2BT menu item.  On the Port Selection dialog that opens, select "Windows WCL" to use Bluetooth without the BLED112 dongle or the appropriate COM port if you have this dongle.  Although only v1.00 of the extender is needed for use with this dongle, you can of course use it with v2.00 if you wish.

Here are some additional notes:

1.  The Power, Stop and digit buttons are all active for each of the four .rmir files but for the "in" files only the Power button performs an action and for the "out" files only the Stop button does so.  The others in this list do nothing, but the TV LED gives a brief flash (normal flashes are about 200ms, these are just short flickers).  This is useful to check that the extender is properly installed before pressing Power or Stop.  If the TV LED is already lit, such as after pressing the Devices button, pressing a digit key turns it off.  Always have the LED off before pressing Power or Stop, as otherwise the number of flashes is unclear.

2.  The TV/180x devices other than TV/1800 have no effect if set instead of TV/1800 as the TV device.  The digit buttons will give a brief flash, Power and Stop will do nothing.

3.  If you get a message that the signature of the remote does not match that of the setup you are trying to upload, then you are trying to install the extender for the wrong remote.  This check ensures that you do not inadvertently install the wrong extender.  Do not override this warning, even though the message gives you the opportunity to do so.


Graham Dixon
May 13, 2019





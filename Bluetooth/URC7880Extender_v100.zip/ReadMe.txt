Bluetooth Extender v1.00 for URC-7980, URC-7955 and URC-7880.

RMIR v2.07 includes a new interface, JP2BT, to connect RMIR by Bluetooth to remotes that support the UEI Bluetooth "One for All Setup" phone app.  At present we know of three such remotes, the URC-7980, URC-7955 and URC-7880.  In place of an interface cable, this interface requires the Bluegiga BLED112 Bluetooth Low Energy Dongle by Silicon Labs:

https://www.silabs.com/products/wireless/bluetooth/bluetooth-low-energy-modules/bled112-bluetooth-smart-dongle

available from them for $10.45 or in Europe from RS for �8.52 at

https://uk.rs-online.com/web/p/bluetooth-adapters/8077742/#

As supplied, these remotes support downloading via Bluetooth but not uploading, as the functionality required in the remote for uploading has been only partly implemented by UEI.

Bluetooth Extender v1.00 fixes this partial implementation, providing both upload and download capabilities and so allowing full support of all RMIR features.  The extender is installed with RMIR via Bluetooth, so no other cable is required to upgrade the remote to full RMIR support.  The extender takes up no room in the user memory and is permanently installed until actively uninstalled, and so survives a change of batteries and even a factory reset.  Separate versions of the extender are available for the three remotes.  This ReadMe applies to all of them.

What is provided in the file URCnnnnExtender_v100.hex (where nnnn is 7980, 7955 or 7880 as appropriate) is actually an extender installer.  Installing the extender itself is a three-stage process, (a) loading the extender installer, (b) running the installer to install or uninstall the extender, (c) deleting the installer.  Here are the details.

(a) Loading the extender installer

It is advisable first to download the current setup with RMIR (via Bluetooth) and to save it as a .rmir file.  At the same time, you can check that three prerequisites are met by your current setup: (i) the "Memory usage" progress bar shows that there is at least 1760 bytes (1440 bytes for the URC-7880) of free memory, (ii) the "Key Moves" tab shows that the setup does not include any key moves, (iii) you do not have any macro or learned signal on the Power or Stop buttons that are used during the installation.  If any of these are not satisfied, you need to do a factory reset before loading the installer.  You can re-load your saved setup after activating the extender.  To do a factory reset, press and hold Magic until the LED is steadily lit, then enter 981.  Wait for the 4 flashes that confirms the factory reset is complete.  If you do a factory reset then you will need to use Search when connecting to Bluetooth and press and hold Devices and Activity buttons during search to re-activate Bluetooth on the remote.

You can load the installer either after a download, or if you have previously verified the prerequisites then straight after connecting, without repeating the download.  Select the File > Install extender... menu item and navigate to the folder containing the appropriate URCnnnnExtender_v100.hex file.  Select it and press Open.  The installation should commence and show its progress in the progress bar as "INSTALLING: xx" where xx is a percentage.  When complete, a pop-up message "Installation succeeded" should appear.

You can further verify the installation by now doing a download.  The Devices tab should then show 9 new entries (7 for the URC-7880) with Device Type = TV and Setup Codes 1800 to 1804 and 1806-1809 (1806-1807 for the URC-7880).  (It is intentional that there is no 1805).  Finally, disconnect the Bluetooth connection.  The next steps are performed on the remote itself.


(b) Running the installer to install or uninstall the extender

You next need to set the TV device to TV/1800.  Press Magic till the LED is steadily lit, then repeatedly press Devices if necessary until it is the TV LED that is lit.  Then enter 1800.  The LED should flash twice on success.  Now select the TV device.  To test that the installer is now successfully selected, press a digit key (see note 1 below).  The LED should give a brief flicker.  This performs no action, but it is a safe way to test that all is well so far.  Now press Power to install or Stop to uninstall the extender.  Count the flashes of the TV LED for a result status:

2 flashes for a successful install/uninstall
3 flashes if the extender is already installed or uninstalled (so no action took place)
4 flashes if the battery is too low to perform the installation.

Finally you need to disconnect and reconnect RMIR for it to recognise that the remote now accepts uploads.  Here are some additional notes:

1.  As well as the Power and Stop keys, the digit keys are also active.  They do nothing, but the TV LED gives a brief flash (normal flashes are about 200ms, these are just short flickers).  This is useful to check that the extender is properly installed before pressing Power or Stop.  If the TV LED is already lit, such as after pressing the Devices button, pressing a digit key turns it off.  Always have the LED off before pressing Power or Stop, as otherwise the number of flashes is unclear.

2.  If pressing the Power or Stop button gives a brief flicker, like the digit keys, rather than 2 to 4 flashes then there was an error in loading the installer and no action has occurred.

3.  The TV/180x devices other than TV/1800 have no effect if set instead of TV/1800 as the TV device.  The digit buttons will give a brief flash, Power and Stop will do nothing.

4.  RMIR checks that the extender installer you are loading is the correct one for your remote, so there is no danger of installing the wrong one.


(c) Deleting the installer

It is not necessary to delete the installer.  If you loaded the installer into your normal setup, you can simply reset the setup code for the TV device and the remote will work as before.  But the installer takes up nearly half the available user memory (three-quarters on the URC-7880) and is no longer needed after running the installation process. You can delete it in several ways.  The simplest is just to upload your saved setup, as uploading will now work.  To do so without a saved setup, first reset the setup code for your TV device, then download from the remote and go to the Devices tab in RMIR. Delete the 9 (or 7) device upgrades that form the installer (TV/1800 to TV/1809 or TV/1807 with TV/1805 absent, see (a) above) and then upload the result.  Or, of course, you can do a factory reset and create a fresh installation.  As mentioned above, a factory reset does not remove the extender.  If you ever do want to remove the extender, re-load the installer and follow the instructions in (b) for uninstalling.  Remember that you will not be able to remove the installer afterwards other than by a factory reset, unless you also have a JP1.x cable and use that interface to the remote, as you have removed the ability of RMIR to perform Bluetooth uploads to the remote.

Graham Dixon
April 18, 2019






                               Atlas/Atlas OCAP JP1.3 Extender Readme


N O T I C E
============

There have been issues with using this extender "from scratch" because certain
data that are in the remote by default differ between cable operators.  The
most reliable way to build an extended remote is to download a "base" remote 
configuration with IR (and save it!) and then to install the extender into that 
configuration.  This will ensure that the default data from your cable provider 
loaded into the remote remains correct.  Installation of the extender requires 
EXTINSTALL V2.0 (to support the JP1.x remotes) which also requires the Microsoft 
Visual C++ 2005 run time, available from Microsoft.com  The command line to 
install the remote is:

Extinstall 3A00ext-notes.hex yourirfile.ir newirfile.ir -sig=$0600
Extinstall 3A33ext-notes.hex yourirfile.ir newirfile.ir -sig=$0600

The extender can also be installed using the "Merge using Extinstall" function 
in IR (again requiring Extinstall V2.0 and MS VCC+ 2005 run time)


This extender supports a number of Atlas/Atlas OCAP remotes.  Specific remotes 
are difficult to identify other than through their EEPROM signature, which can be 
read with the IR.exe.  Some of the Atlas remotes have white stickers in the 
battery compartment to help identify the remote.  This extender has been tested
with the following labels:

	URC-1055BA1	No learn, black, Time Warner		30003000
	URC-11055	Learn, black, Time Warner		30003000

	URC-1055BC2	No learn, black, Time Warner		30333033
	URC-1056BC1	OCAP, Learn, Silver/Black, various	30333033
	URC-1056BG1	OCAP, No learn, Time Warner		30333033

In addition the extender may support the Comcast DVR JP1.3 remote (3039) and teh 2150 (3032) however
I no longer have any of these remotes.  PM unclemiltie in the forums if you would like to test the extender 
on either of those remotes


It is possible there are other remotes in the Atlas family that would be
compatible with this extender, however remember that those remotes have not been
tested.  You can try as the extender will not activate if the activation 
keymove does not find the right codes in the remote.

This documentation is specific to extender v2.04 The version number ($0204) is 
stored at EEPROM[$07FE]

Revision history

	version		features/changes
	v 0.01		Initial version, port of URC-9960B01 extender to atlas remote
	v 0.02		Fixed LDKP, other bugs, clean up
	v 0.06		lots of bugs fixed (binky123, unclemiltie) fixed odd device changes, multiplex protocol
			added preliminary support for  URC-1067 JP1.3 Comcast DVR 
	v 0.07		temp device selection fix by binky
	v 0.08		more fixes for device selection in keymoves and macros
	v 1.00		Final release version with all known bugs fixed
	v 1.01		Fixed toadtog bug not toggleing if side was empty
	v 2.00		moved special protocols to private area to conserve space
			added backlight toggle control for backlit 30333033 remote
	v 2.03		Added mike england's backlight control protocol as default, move to hidden area

			cleaned up RDF and button restrictions
	v 2.01		fixed (hopefully) key being repeated while in macro (also 
			had impact on LKP's when key was held)
	v 2.02		fix bug in key held repeating entire macro for pseudo-device keys
	v 2.03/2.04	fix bugs, clean up, remove 3039 extender to new project, RDF cleanup



BASIC FEATURES:
===============

  You can put a Macro or KeyMove on any key
  You have room for lots more KeyMoves and Macros
  Macros can be Nested
  Macros are fast
  Very flexible device selection
  Improved (very different) Fav list processing
  Included protocols for Pause, DSM, LDKP, Device Multiplex and ToadTog
  Optional second shift key

 
  No Learned signal support
  No Scan support
  No direct keying of EFC codes on the remote
  No long-press-setup functions
  No modem download support
  No multi-macro support


S P E C I A L  N O T E S:
=========================

When the remote is restarted (new batteries, reset, etc) all of the HT device 
indexes are set to $00 (CBL).  There is no support in this version of the extender to set
the initial HT device indexes as has been done in other extenders.

These remotes are dependent on the setup codes for the devices being either present in
the base ROM or in the upgrade table.  The remote checks all of the device setup codes
on reset and if the devices are not present the remote will erase the area of the EEPROM
where the extender resides and will reset the signature to the unextended signature. The 
extender is shipped with default device setup codes in place for all devices.  If you
change the setup codes and on reset you see the LED blink 5 times, you can be assured that
the extender has been erased and the signature has revered to the  old signature.   (a side
effect of shipping with all of the setup codes is that EXTinstall will change your setup 
codes when it installs the extender, you will have to set them back after installing)

A built-in failsafe in the extender will detect that the signature has changed and will 
operate as an unextended remote until a new version of the extender has been uploaded 
with the extender  signature in place.  While operating as an unextended remote, the LED 
will blink twice for every keypress to indicate that the extender is not being used.  While
the extender is not being used, none of your keymoves or macros will be valid.



INCLUDED DOCUMENTS
==================

  ReadMe.txt:

    (This file.) Describes overall features, usages and trouble shooting tips.

  Keys.XLS:

    An excel spreadsheet with all of the assigned keys and keycodes used in this extender
    and in the unextended remotes. 

  3A0ext-notes.hex and 3A33ext-notes.hex

    the extender in a form that can be merged with your existing IR configuration
    via Extinstall (Version 2 required) including notes to identify the special 
    protocols and pre-installed upgrades

  *.RDF 

    the RDF file, place in your RDF directory to enable IR and RM to use this 
    extender
   
  EXTINSTALL.EXE

    Extinstall Version 2 (this is the same as is in the tools directory, copied here
    for convenience)




INSTALLATION AND ACTIVATION
===========================

This extender is distributed only as a HEX file with only the extender code 
for use with EXTINSTALL (version 2 is required). This HEX file can be integrated 
into an existing IR file for  your remote which will maintain all of the original 
keymoves, macros and upgrades.

Note:	When you upload this extender to your remote for the first time, 
	IR will give you an error message telling you that the signature 
	does not match, this is normal and you can dismiss the error.  

Activation of this extender is very different than previous JP1 extenders.  Once 
activated, this extender will remain active until it is deactivated by the user. 
(activation will survive removal of the batteries, resets, etc)  Two keymoves are 
provided in the default IR and HEX configurations to activate and deactivate the extender.  

The keymove to activate is on the TV/OK key (not visible to IR).  To activate, press the TV/OK key 
after initial upload to the remote.  When the extender is activated, the device button
will flash 4 times to  indicate activation.  Until deactivated, the extender will remain 
active.

This extender must be deactivated to return the remote to normal (non-extended) operation.  A
keymove to deactivate the extender is included in the HEX files that are distributed with the 
extender and is defined on a special key "Deactivate".   

To deactivate the extender open your configuration in IR, move the deactivate keymove 
to a physical key and upload this configuration to your remote.  When you press the key that
triggers the deactivate keymove, the device button will flash 4 times to indicate that the
extender has been deactivated and the remote has been returned to its normla, non-extended
state.  You can the upload non-extended IR files (IR will again warn you that the signature
does not match)  

REMINDER:  To switch back to the non-extended remote you MUST FIRST deactivate 
the extender BEFORE loading in any non-extended IR files (with the default
signature) as those IR files may overwrite the extender and cause unpredictable 
results


DEVICE SELECTION:
=================

There is no normal device selection.  There is no VPT.  There is no
Transport Punch Through.  Device selection is similar to a true home theater
setup where key sets can be assigned to different devices. 

Instead there is a device selection mechanism by key set that has a
superset of the power of all the above;  But you must define macros to use
and customize it.

The device keys  have no built in meaning.  You must define macros to have 
any device selection at all (default macros are included for all of the device 
keys, these can, of course, bechanged)

There are commands that can be used in macros to control device
selection.  Each command specifies the key set and the Device Index that will
be used for keys in that set.  For example V_TV says the TV device will be
used for keys in the "Volume" set.

There are 7 Key sets: Menu, Channel, Volume, PIP,  Transport, Other and
Temporary(X). 

For the URC-1055 there are 5 Device indexes:

	CBL, TV, DVD, AUDIO and AUX

For the URC-1056/OCAP there are 5 Device indexes:

	CBL, TV, DVD, AUDIO and VCR


There is one additional command X_Cancel which cancels the last temporary 
device selection. An X_Cancel is "implied" at the end of processing all pending
keys from the macro buffer.  (ie: you do not have to issue an X_Cancel at the 
end of your macros)

To achieve simple device selection (no VPT, TPT or HT) you would put a 5
command macro on each device key, for example the TV device key would have
the macro:   M_TV; C_TV; V_TV; T_TV; O_TV.  The extender ships with these 
built-in macros to make the first use of an extender easier.

To achieve VPT, replace the V_ command within the macro for each device
that should have VPT enabled with the command from the device to which VPT
should be set.  For example, to enable AUDIO VPT on your DVD, the DVD key
macro might be:  M_DVD; C_DVD; V_AUDIO; T_DVD; O_DVD

To achieve crude TPT (such as most of the UEIC remotes) replace the T_
command within the macro for each device that should have TPT enabled with
T_VCR.  For example, your TV key macro might be:
M_TV; C_TV; V_TV; T_VCR; O_TV

To achieve dynamic TPT (similar to the URC7800).  Omit the T_ command from
the macro for each non Transport device and include it in the macro for each
transport device (VCR, DVD etc.).  When you select a non transport device,
the T keys will all remain associated with whatever transport device was
most recently selected.

Shifted keys all go into the key set containing their unshifted
counterpart.  For example SHIFT-Stop is in the T set.  Phantom keys are in
the O set.  Device keys are in the O set;  But most people will put macros
on device keys.  If a key is a macro, it doesn't matter which set it is in.
The set only matters for KeyMoves and for keys defined by setup code.

  
Temporary Device Selection:
---------------------------

Within a macro, you often want to issue a key to a specific device
regardless of the previous device selection and without disturbing that
previous device selection.  You use X_ commands to do that.  For example,
the sequence
X_TV; 0; 3
in a macro would send the 0 and 3 keys to the TV regardless of the previous
device selection.

The X_ selection is automatically canceled when the outermost macro (see
nested macros) completes.  If the above example were intended for use as a
top level macro, there would be no need for it to explicitly cancel its X_
command.  If the above example were in a general purpose macro that might
be called by other macros, you probably should change it to:
X_TV; 0; 3; X_Cancel

While an X_ command is active, it applies to all keys.  The usual division
into  Menu, Channel, Volume, Transport and Other doesn't apply.

NESTED MACROS:
==============

This remote plays macros out of RAM (instead of the register file as the 
previous JP1 remotes did) and thus the length of a macro is virtually unlimited.
The actual limitation is about 240 keys, however with nested macros you can 
build extremely long and complex macros.  

You can nest macros to any depth.  Any key that is a macro when used from
the keyboard is the same macro when used inside another macro.

This is very different from the base remote and from other extenders.  Pay
careful attention to this detail when converting a configuration for use
with this extender.  There is no protection from infinite loops when a macro
nests into itself.

Many people have used the fact that macros don't nest (in the basic remote)
for things like a Power macro that uses the normal Power key.  Find and
change anything like that in your configuration (see "Cloaking with Shift").

*** rewrite this section  ***
There is a 18 byte macro buffer, consistent with the size of the non-extended
remote.   That doesn't set a limit on the total number of
commands executed by one macro (virtually unlimited).  It limits the number
of commands "pending" at any one moment.

To understand "pending" commands, imagine 4 macros, A, B, C, and D:

	A = B; C; D
	B = 1; 2; 3
	C = 4; B; 5; 6
	D = 7; 8; 9

when you press A, you get 1 2 3 4 1 2 3 5 6 7 8 9, which is 12 commands, but
in executing those 12 commands, there were never 12 commands "pending".
When the extender processes the first B there are 5 command pending:

	1; 2; 3; C; D;

Later it process the C and there are again 5 commands pending:

	4; B; 5; 6; D

When it processes the second B there are 6 commands pending

	1; 2; 3; 5; 6; D

The whole 12 commands are sent with a maximum of 6 ever pending.  You should
be able to design ridiculously long macros without ever hitting the limit of
19 pending commands.

FAST MACROS:
============

Both the hold time and the delay time for commands in a macro have been reduced.  I
think that is necessary to make macros useful.  There are situations in which
you need to add back some hold time or delay time.

For delay, you can use:

1)  For a very small delay, use a redundant device selection command.  If you
know that an X_ selection won't be in use at the relevant point in macro
execution, you can use a redundant X_Cancel as a tiny delay.  If you know or
use any other device selection, you can use it again as a delay.  For example,
if you want a delay between digits in the macro "C_TV; 0; 3" you could use
"C_TV; 0; C_TV; 3".

2) For a slightly longer delay, use an undefined key code. The actual amount
of delay will depend on the number of items in your KeyMove and Macro area.
For example, if you have no KeyMove or Macro for Phantom3, you could
use Phantom3 as a delay.

3) For a long delay, use a KeyMove connected to the Pause protocol (TV/1104).
The hex command is the amount of delay from 01 (smallest) to FF.  The delay
is in units of about 0.1 seconds.

For adding back hold time, I haven't provided anything in this version of
the extender, except for the last step of a macro as follows.

HOLDING LAST STEP OF A MACRO:
=============================

If the last step of a macro transmits a signal, and you held down the
original key that started the macro through the entire macro execution,
the extender will continue the last signal while that button is held,
just as the remote normally does for a signal that is the only action of
a button.

This feature acts the same for ToadTogs and DSMs as for ordinary macros.
It acts the same for mini-macros (from a Fav list) as well, except that all
mini-macros are really exactly 5 commands long, rather than being 1 to 5
commands long as they seem.  IR.EXE pads any shorter mini-macros with NULL
commands to make them 5 commands long.  If a mini-macro is less than 5
commands, its last command is a NULL command, so holding the key won't make
a difference.  If you want holding the key to make a difference, try padding
the beginning or middle of the mini-macro with redundant device selection
commands rather than letting IR.EXE pad the end with NULL commands.

In rare cases, you want to defeat this feature and avoid having the last
step of a macro continued if the user holds the key.  You can most easily do
that by adding an X_ command to the end.

SHIFTED KEYS:
=============

Pressing the Setup key causes the next key to be "shifted".

The shift only affects the lookup of the key as a KeyMove or Macro.  If no
KeyMove or Macro is found for a shifted key, the remote then checks whether
the unshifted version of the key is defined by the setup code.

The Setup key only acts as a shift key when used from the keyboard.  When
used in a macro the Setup key is just an ordinary (O set) key.  When used
from the keyboard the Setup key is both a shift key and an ordinary key, so
you can get some confusing or interesting (depending on your intent)
behavior by defining a KeyMove or Macro for the Setup key.

To use a shifted key in a macro use the "Add Shift" option of IR;  Do not
try to make it shifted by preceding it with the Setup key.

Changing the Shift Key:
-----------------------

In the General/Other_Settings pane of IR.EXE you can configure shift to be
a different key or two keys.

"Shift Button Keycode" defines the primary shift key.  The value is displayed
as a decimal number.  The default is the usual shift keycode for the "setup"
or "P" keys for your remote (usually 2 in most UEI remotes). You can
change it to any key you prefer.  If you look up the keycode in Keys.xls
that value will be in hex.  You can type a hex value in the settings area by
prefixing it with "$".  IR will change it to the decimal value.  For example,
if you type the value in as $36 and IR shows it as 54.

"Alt Shift Button Keycode" defines an optional second shift key.  If that is
the same as the primary shift keycode then the extender will use only the
primary.  If it is a different valid code, that code will be a second shift.

"Alt Shift" selects whether the second shift key performs an xshift operation
or a ordinary (same as the first shift code) shift operation.  You can select
ordinary to have two shift keys that perform the same operation.  Using xshift
you can have up to three key moves on other keys by having an unshifted
keymove, a shifted keymove, and an xs-keymove.

The second shift key can be a code shifted by the first shift key.  In fact it
can be the first shift key shifted by itself.  For example, I set the first
shift keycode to $02 and the second one to $82 and selected "xshift".  Then if
I press P (setup) once, the next key is shifted;  If I press P twice, you get
the xs version of the next key;  If I press P three times, the next key is
back to normal.

Cloaking with Shift:
--------------------

If you want to define a macro for a key (such as Power) but also use that
key as defined by the setup code (probably in that macro) the trick is to
use the shifted version of the key.  For this to work, you must not define
a KeyMove for the shifted key (in the current device index) nor define a
macro for it.  Then put shift-Power inside the Power macro.  When the
extender fails to find a KeyMove or macro for shift-Power, it looks in the
setup code for a definition of Power and finds the one that you couldn't
access directly because the macro is in the way.

Shifted device selection commands:
----------------------------------

In other extenders shifted versions of the device selection commands (shift
M_VCR etc.) have been available as phantom codes, because they had no built in
meanings.  In this extender these commands cannot be shifted or Xshifted

KEY SETS:
=========

T  =  Rewind,Play,FastFWD,Stop,Pause,Record,Replay,Live
V  =  Vol+,Vol-,Mute
C  =  digits,Ch+,CH-,Enter,*,Last,Source,Fav  
M  =  List,Up,Down,Left,Right,OK,Settings,Menu, Page+,Page-,Day+,Day-,Guide,Info,Exit
P  =  PIP on/off, PIP swap, PIP move, PIP Ch+, PIP Ch-
O  =  A,B,C,D,TuneIn1-3,Phantom keys,DiscreteOn/Off,Power,Setup

** The D and Menu keys are only available on the OCAP remotes

FAV/SCAN:
=========

Note:  The unextended Atlas remotes did not support FAV/Scan mode even 
though a FAV key was included.  This extender implements the FAV mode 
similar to that of other JP1 extenders.

You can use IR to define a Fav list of up to 15 mini-macros of up to 5 keys
each.  IR handles all 15 mini-macros together as one line item in its Scan/Fav
tab.  Within that line item, the mini macros are delimited by "{pause}".  IR
also allows you to create additional whole Fav lists;  But the remote can't
use them.

   The extender operates the Fav list differently than other unextended remotes
in three important aspects:

1) The extender executes just one mini-macro each time you press the Fav key
(advancing through them circularly).  The unextended remote will continue
executing the mini-macros with 3 second pauses in between until you press
another key to stop it.

2) The extender will switch the temporary device index to equal the Fav
device index whenever it starts a Fav mini-macro.  The unextended remote
only recognizes the Fav list if the device index already matches the Fav
device index.

3) The unextended remote will do a Scan operation instead of a Fav list
operation whenever the Fav key is used in a device index that doesn't match.
The extender will never do a Scan operation.  To have it do something other
than a Fav operation on certain device indexes, you must define a Key Move
for Fav for each such device index.  (The Key Move will only override the
Fav List if IR.EXE puts the key move earlier within the
KeyMove/Macro/FavList pool than it puts the FavList.)


SPECIAL PROTOCOLS:
==================

This extender includes by default in the distributed IR file support for PAUSE,
ToadTog, LDKP and DSM special protocols. The special protocols are enabled in 
IR via the "special protocols" tab.  See additional documentation below on how to 
use these protocols.   



PAUSE Protocol:
===============

Included with the extender is the PAUSE protocol however this pause is different from
many of the other extenders.  The other extenders used the pause value as the number of
times through an internal delay loop in the remote.   This extender has tuned the PAUSE 
protocol such that each increment of the pause value is equal to 100ms of delay.  Thus,
you will likely find that pause times from other remotes will be very different from 
the times in this remote. 

The value for the Pause is determined by the first (upper) byte of the keymove.

Note: the keymove must be a hex type keymove, this remote will not call the protocol if
the keymove is a "key type" keymove


Device Specific Macro:
======================

This special protocol is packaged as an upgrade protocol (1FC) and an upgrade
device (TV/1103) that are automatically installed when you install the extender.  
If you don't need this protocol and want to conserve upgrade memory, you can delete 
those upgrades.

This protocol allows you to build a macro that is only loaded and executed for 
a specific device and will allow you to build different macros on the same key  that
are executed for specific devices. 

To use DSM, use the Special Protocols tab and select DSM in the parameters pane.

Device Multiplexor:
==================

This special protocol is packaged as an upgrade protocol (1FE) and an upgrade 
device (TV/1101) that are automatically installed when you install the extender.
If you don't need this protocol and want to conserve upgrade memory, you can delete 
those upgrades.

The Device Multiplexor allows you to use keys to change the device setup codes in
the remote.  This is especially useful on remotes with limited number of device keys
such as the Atlas JP1.3 remotes.  To use this protocol, use the special protocols 
tab in IR.  Assign the key to change the device, the device type and the new setup
code.  When the key is pressed, the device specified will be changed to the specified 
setup code.  


Long/Double keypress:
=====================


This special protocol is packaged as an upgrade protocol (1F9)
and an upgrade device (TV/1106) that are automatically installed
when you install the extender.  If you don't need this protocol
and want to conserve upgrade memory you can delete those upgrades.

This special protocol allows you to execute either one of two key
sequences based on two different key press patterns:

  Long Key Press: Shorter vs. Longer than the specified duration.

  Double Key Press: Single vs. Double press.  (A double press
      is two consecutive key presses within the specified duration.)

Setup
------

In IR, Select the "Special Protocol" tab

1:  In the Bound Key section, select the bound device and key  

2:  In the Parameters pane, select LKP or DKP and the duration as 
    described above.

3:  In the Macro definition, add the keys for the Short/Long or
    single/double key presses.

Durations are expressed as digits 1 through 15 and have durations
of approximately:

      1 ... 0.76 sec
      2 ... 1.52 sec
      3 ... 2.28 sec
      4 ... 3.04 sec
      7 ... 5.32 sec
     11 ... 8.36 sec


ToadTOG - build toggles and discrete codes
==========================================

This extender includes an enhanced replacement for the ToadTog
protocol.  It is packaged as an upgrade protocol (181) and an upgrade device
(VCR/1800) that are automatically installed when you install the extender. If 
you don't need a ToadTog protocol and want to conserve upgrade memory you
can delete those upgrades.

ToadTog lets you construct toggle functions from discrete functions, and/or
construct discrete functions from toggle functions, and/or track the state of
device toggles so that other functions may be sent differently depending on
that state.  It does this by testing the state of a toggle (see below) and then
sending a sequence of keystrokes depending on the state.  All of these are 
configurable through the IR special protocols tab.

There are 8 individually selectable toggles that retain state of the 
devices being controlled. You will need to use one of these for each toggle 
that you will be using in the remote.

Each ToadTog entry can test or change the state of the toggle in one of
four ways AFTER the command sequence has been loaded into the macro buffer
for processing.  These are:

    Toggle	toggle the state of the toggle bit
    test only	test only, do nothing to the state of the toggle bit
    force off	force the toggle to an off state
    force on	force the toggle to an on state

IR allows you to build your toggles or discrete commands by defining key
sequences that will be loaded and processed based on the state of the toggle
and then allowing you to set the state of the toggle.  The examples below show
how to build a discrete on/off from only a power toggle.  Similarl toggles can
be used to create a power toggle from discrete's, or a discrete device
selection command.  


Discrete on/off

In IR, you select a device and a keys for the new functions that you will
enable.  In this example we use DiscreteOff/DiscreteOn.  Next select an unused
toggle (toggle 1).  For the discrete off command, use the "force off" condition
that will tell the remote that after the command has executed the device will
be in the "off"state.   Next,define the sequence of keys that will execute with
the device in the "already on" state and in the "off-on" state.  If the device 
is already on, we want to send a "power toggle" command to the device to turn it 
off.  If the device is on the off state, we want to send no commands to it.

Similarly, for the discrete on, we will use the same toggle, select the
"force on" condition, and send a power toggle when the device is off and nothing
when it is on.  When you are finished you should see something like this:


VCR  DiscreteOff  ToadTog(1,Forceoff) on/off:power, already off: <blank> 
VCR  DiscreteOn   ToadTog(1,Forceon)  already on:<blank>, on/off:power

Backlight Toggle Control:
=========================

(URC 1056 with signature 30333033 only, thanks to Mike England)

This special protocol is packaged as an upgrade protocol (1F8) and an upgrade 
device (TV/1105) that are automatically installed when you install the extender.
If you don't need this protocol and want to conserve upgrade memory, you can delete 
those upgrades.

The toggle control allows you to control if the backlight will go on when a key is 
pressed.  To use this protocol, Add a keymove using TV/1105.  The hex value for the 
keymove will determine the behavior of this protocol

if Bit 7 = 0, the protocol will toggle the backlight enablement 
if Bit 7 = 1, Bit 0 will be used to enable (1) or disable (0) the backlight 
if bit 6 = 0, blink the current device key
if bit 6 = 1, don't blink the current device key

For example, the value $00 will toggle the backlight and blink the device key and 
the value $40 will toggle the backlight and not blink the device key 




RDF FILES:
==========

The enclosed RDF files are  needed in the RDF directory for IR.EXE to edit an eeprom 
image of the extender and for RM to build upgrades properly.

The above RDF as well as the original RDF files are required in the
directory where you run the ExtInstall program. 

If there is an updated RDF you should probably use them instead of the RDF's 
included here.  

TROUBLE SHOOTING:
=================

This is a complicated extender that may still have some bugs in it, and it
lets you define very complex behaviours for your remote, which will probably
have errors on first try.

The major method of trouble shooting is to break complex operations down
into their parts and see if the parts work individually.

Example:  You have a macro that does some device selection and does two
phantom codes and each phantom code does a ToadTog and it doesn't work.
Assign those two ToadTogs to pressable keys (temporarily for trouble
shooting).  If necessary, define some simple macros to duplicate the
device selection of the complex macro.  Test the individual pieces of the
complex macro and see which work.

Example:  You have a ToadTog that doesn't work:  Make a simple macro or
DSM out of each command list of the ToadTog.  Test the two sequences that
way.

A moderate fraction of macro, DSM and ToadTog problems are due to one of
two timing issues:

1)  The extender reduces (to the minimum value) the duration of signals which
are not the very last step in its macro buffer and signals which are processed
after the user has released the key that started the whole operation.

If you suspect you have a duration problem, you should confirm it with two
tests.  Put the single function on a pressable key and press and hold that
key.  If that doesn't work, something more basic than a duration problem is
wrong.  Put a macro or DSM on a pressable key that is just the problem
function followed by an X_Cancel.  When you press that key, the function is
not last, so the duration will be minimum.  If that introduces the failure
you know it's a duration problem (there are then a variety of approaches to
fixing it).

2)  The extender reduces the time between signals within any automated
sequence of signals.  If functions work when manually sent in sequence, but
don't work when automatically sent in sequence, and you determine it's not a
duration problem, then it's time to try delays.  Define a KeyMove for a
moderately long use of the pause protocol.  Insert that before and/or after
the problem function(s) in your sequence.  If that fixes it, you've confirmed
that it is a timing problem and you can then experiment to fine tune the
correction to fix the problem with minimum increase in the time it takes the
whole operation to complete.

Rarely, a device is sensitive to any signal at all right before or right
after its signal.  In those cases, the best you can do is find the smallest
added delay that fixes the problem.

More often, a device just needs time to do the operation you gave it before
it is ready for the next.  In a complex macro, you may have an alternative to
adding delay.  If you're sending two commands to device A, then one command to
device B, try sending the command to device B in between the two commands to
device A.  That probably takes one or two extra X_ commands beyond doing it the
simple way, but probably takes less total execution time than simply adding
delay.

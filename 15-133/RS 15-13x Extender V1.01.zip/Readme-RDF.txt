Notes:

The 135 has a home theater mode via the MS button. The 133 and 134 lack this button, but you can access home theater mode via a macro. To use Home Theater mode, create a macro on a physical button that uses the phantomMS button. 

The 133 has 8 device buttons, the 134 has 5, and the 135 has 7. But all have 8 devices. Use dev6, 7, or 8 in macros for additional devices in the 134 and 135.
 

In KM, you can use the 15-135 for the 133 and 134. Some of the keys remap as follows:

133 key = 135 key
-----------------
yellow = discreteOn 
blue = discreteOff 
green = phantom1 
red = phantom2 
start = HD 
Xbox = AV2 
PC = VCR 
PSX = dev8 
VCR = DVR
discreteOn = Audio
discreteOff = Surround
phantom1 = Center
phantom2 = Rear
phantom3 = pip on/off
phantom4 = pip swap
phantom5 = pip move
phantom6 = pip freeze
phantom7 = Mode
phantom8 = Aspect
phantom9 = HDMI_In
phantom10 = DVR[List]
phantom11 = Comp_In
phantom12 = CC
phantom13-15 = phantom3-5
phantom16 = TV_In
phantom17 = AV_In
phantom18 = Dash
phantom19 = phantom6

134 key = 135 key
-----------------
yellow = discreteOn 
blue = discreteOff 
green = phantom1 
red = phantom2 
fav = HD 
dev6 = AV2 
dev7 = VCR 
discreteOn = TV_In
discreteOff = AV_In
phantom1 = Audio
phantom2 = Surround
phantom3 = Center
phantom4 = Rear
phantom5 = Mode
phantom6 = HDMI_In
phantom7 = Comp_In
phantom8 = CC
Page+ = phantom3
Page- = phantom4
ViewTV = phantom5
phantom9 = phantom6



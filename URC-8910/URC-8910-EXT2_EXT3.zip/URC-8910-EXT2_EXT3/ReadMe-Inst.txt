   This is an installer for extenders, such as the ones in 1994ex2.zip and
1994ex3.zip.  It also can install certain special protocols and can merge
protocols, devices, Key Moves, and Macros from two files into a new file.

   To run it make sure an RDF file for each input file is present either
in the current directory or the directory containing the input file, then
type:

ExtInstall extender.hex old.txt new.txt
or
ExtInstall protocol.hex old.txt new.txt
or
ExtInstall one.txt two.txt new.txt


   Where extender.hex or protocol.hex is the extender or special protocol,
old.txt is an eeprom image saved by IR.EXE from the remote and new.txt is
the output file to be created by the installer.

   Or one.txt and two.txt are eeprom image files.

   There is a "signature" in each of extender.hex and old.txt which tells
ExtInstall which RDF file to use.  In this version ExtInstall gets the locations
of Adv memory and Upgrade memory from the RDF files, so it can be used to install
extenders which change those memory areas.  There is other information I hope to
get from the RDF files in a later version of ExtInstall to allow more advanced
features, such as moving most of a configuration across models of remote.

   The error messages are pretty poor, so if you do something wrong, good luck
guessing what it was.  Hopefully, I can improve that too at some point.

   If the first file is an extender, then the resulting file will have the
memory layout of the first file (and be based on the same RDF as the first file).
In merging the two files, anything not specified in the first file will be taken
from the second.  Anything except a Macro specified in both will be taken from
the first.  A macro specified in both will come from the second file.

  If the first file is not an extender (is a special protocol or an eeprom image)
the result file will be based on the second file.  Only protocols, devices,
key moves, and Macros will come from the first file.  Protocols, devices, key
moves and Macros from the second file are also included, but only if they don't
collide with the ones from the first file.
Release Notes :
(1) This files are meant for URC-6011B series of remotes 
(One For All brand) that have been upgraded with 8kBytes 
memory chip and those that return setup memory area 
address of 0x1e0a.

(2) This files are produced by modifying 6012ex3_1.zip 
distribution available from JP1 yahoo newsgroup. For 
details, checkout the original distribution that contained
files for remotes that returned setup area of 0x1c15 etc.

(3) Eventhough I have been able to get 6011B remote that 
was extended with 8KByte EEPROM work using this files,
there still might be some issues.

(4) No support is available from me if you run into any
problems (since I do not understand most of the stuff 
anyways).

Files in this distribution :
10/07/2003  09:57p               3,800 6011B_8k_1e0a_x3.rdf
10/08/2003  12:26a              36,096 6011B_8k_1e0a_x3.txt
10/03/2003  03:54p               2,625 6011B_8k_1ea0.rdf
10/08/2003  01:07p               1,028 ReadMe.txt
               4 File(s)         43,549 bytes
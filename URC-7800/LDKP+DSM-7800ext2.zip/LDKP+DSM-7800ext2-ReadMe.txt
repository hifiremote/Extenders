LKP/DKP/DSM Combo Special Protocol for Cinema7+ (URC7800) with extender2
20 May 2005   converted from standalone protocol for 2116/8910/HTPro
4 Sept 2005   more C7ext2-specific notes and examples
Text of protocol and device upgrades is at the end of this file
==========================================================================

This is a special protocol that allows you to attach a Device Specific Macro, 
a Long Key Press, or a Double Key Press to a key on the Cinema7+ (URC7800)
using an extender2.

It is essentially a combination of the DSM protocol and the LKP/DKP protocols.

* The Device Specific Macro option allows you to assign a macro to a button of 
  a specific device, instead of it being active on all devices.

* The Long Key Press option allows you to assign two macros to a button of a 
  specific device, and will call one or the other based on how long the button 
  is held down.

* The Double Key Press option allows you to assign two macros to a button of a 
  specific device, and will call one or the other based on the whether the button
  is pressed once or twice within a specified timeout period.

The way you set it up is similar to the DSM special protocol in the 
special-protocols.xls speadsheet.  You set up macros on phantom/shift keys using 
the Macro tab in IR for the macros you wish to execute.  You then create a key 
move with the setup code tied to the special protocol on each key of your choice.  
You use the Hex commands on the key move to specify which protocol option to 
invoke (DSM, LKP, or DKP), the length of the timeout period, and the phantom 
keys with the macros to be executed.

The Hex command in the key move is two bytes long and consists of the following:

  - First Macro Key byte:

    This is the button hex code of the key holding the macro to execute for a 
    short key press (for LKP), a single key press (for DKP), or all key presses 
    (for DSM).  This is the same button hex code as would be used in the DSM 
    in the special-protocols.xls spreadsheet.

  - Second Macro Key byte:

    This is the button hex code of the key holding the macro to execute for a 
    long key press (for LKP) or a double key press (for DKP).  This is not 
    required when using the DSM option.  This is the same button hex code as 
    would be used in the DSM in the special-protocols.xls spreadsheet.

Installation
------------

In the IR.exe, paste the 3 device upgrades in the Devices tab while making
sure that the Protocol > FF checkbox is checked.

Paste the protocol upgrade in the Protocols tab.
Do not add this protocol to the RDF file.

Setup
-----

Create macros on the phantom keys that you wish to be executed by this protocol.  
Note the button hex code for the buttons on which you have defined the macros.

Create a key move on each button that you want to use the protocol.

  - Device Type:  TV
    Setup Code:   1206 or 1207 or 1208

  - Select the Hex Cmd (not EFC) mode.

  - Create and enter the Hex Cmd as follows:

    Byte 1
	Set the FIRST byte to the button hex code of the key with the macro that
        should be executed for a short key press (for LKP option), a single key 
        press (for DKP option), or always (for DSM option).

    Byte 2
	Set the SECOND byte to the button hex code of the key with the macro that 
        should be executed for a long key press (for LKP option) or a double key 
        press (for DKP option).  The second byte is not required for the DSM 
        option, it can be coded as 00.

You can use the Other Data section of the DSM protocol in the 
special-protocols.xls spreadsheet to calculate the button hex codes to be used.

Example
-------

This LKP example is untested but hopefully good enough to illustrate how you can 
set this up. << Note: this example is made for 2116 and 8910, it might not
work in C7ext2 >>

While DVD is selected, the POWER button powers on/off the DVD only with a short 
press but it ALSO powers on/off the receiver and the TV (but leaving the remote 
in the DVD mode) if you hold it down for a longer press.

Step 1 - Set up your macros.
    Set up a macro to turn on the DVD player, and assign it to the Shift-Power 
        button.  
    Set up a macro to turn on the DVD, Receiver, and TV, and assign it to the 
        Shift-1 button.

Step 2 - Use the LKP device already precoded with control byte $1x where
	x=duration

Step 3 - Calculate the second and third bytes of the hex command.
    The first macro is on the Shift-Power button.  Using the Other Data section 
    of the DSM protocol in the special-protocols.xls spreadsheet, the button hex 
    code is calculated to be $83. Note: this must be a macro, a single key such 
    as shift-1 or phantom1 which turns on the DVD is not an option.

    The second macro is on the Shift-1 button.  Using the same technique, the 
    button hex code is calculated to be $95.

    Together, this generates the 2 byte hex command of $83 $95.

Step 3 - Create the key move.

    Create the key move as follows:

    Bound Key:
      Device: DVD 
      Key: POWER
    Function to Perform:
      Device Type: TV
      Setup Code:  1207
      EFC/Hex Cmd: 83 95		[ ] EFC [x] HexCmd
        (Note that you don't include '$' in the hex cmd field.)


Error Messages
--------------
This section defines the circumstances which will produce an error message on 
the LCD display.

1.  Pressing a second, different key when using the DKP protocol before the 
    timeout occurs.  

    When using the DKP option, if you press a second key that is different from 
    the first key before the timeout period expires, the remote will blink
    6 times and neither the single or double key macro will be executed.

2.  Nesting a second LKP/DKP/DSM key in a macro called from a first key with 
    the protocol on it.

    All sorts of inconsistent things happen when you start nesting this protocol.
    To prevent this from happening, the remote blinks six times if the 
    protocol is called from a macro.  Note that all other keys in the macro that 
    do not have the protocol on them will work correctly.

Special Notes
-------------

1.  Using the protocol on the device keys (untested in C7ext2)

    You can use this special protocol on the device keys.  To do this, set up a
    key move where the Bound Device and the Bound Key are the same.  This allows
    you to do things like use a single key press to select the device mode
    and a double key press to trigger a macro to turn everything on.

    You have to remember the "no nesting" rule, however.  This means you can not
    refer to a device key in a macro if you have this protocol on the key.  To
    make this even worse, macros do not appear to recognize shifted versions
    of the device keys to set the device mode. << Note: in C7ext2 Power also
    appears to belong in this category >>

    This means you will probably need to use the Device Select or Advanced Select
    special protocols to set up additional buttons that you can refer to in the
    macros to select the device.

    I ended up putting the Advanced Select protocol on my unused Sat button and
    used the number keys to set the device (i.e. Sat/1 set my device to VCR,
    Sat/2 set my device to CBL, etc.).  Then in my macros, I used "SAT;1" to 
    change my device mode to what I wanted without referencing the device keys
    themselves.

    Admittedly, after setting up all the macros, key moves, and protocols, it
    ate up a ton of memory, but it still all fit in my configuration once I 
    replaced some of my key moves with learned commands.  No promises for your
    configuration though.  :-)

2.  Timeout period

    The timeout period is specified by the second number in the fourth byte of
    the device upgrade.  The shortest timeout period is 1 and the longest is F.
    The length of the timeout period associated with these numbers vary however,
    based on whether this protocol is on a device key or a regular key.  Your
    best bet it to try various values until you find one that works best for
    you on the key type you are using it on.

3.  Reducing the size of the protocol

    This protocol is pretty large and you can make a significant reduction
    if don't want the DKP option.  To do so, it's pretty easy to chop out the
    Dbl, DblWait, and TestKey portions and recompile.  I don't have space
    problems in my upgrade area, and I like using the DKP on my device keys
    so I left the full code in on my configuration.


Two C7ext2 specific examples, tested and in use
-----------------------------------------------

(1)  I use 4L to synchronize video inputs on TV with the source. 
4L is a keymove for every device. My TV tuner has no discrete tuner
input function so I need a macro to do Ch+ then Ch-. 
Having coded a macro on shift-3( key $97), this DSM keymove code 
TV	4L	<N/A>	TV	1206	$97
does the job for TV.

(2)  VCR can be used as a standard VCR or SAP mode. 
These two macros are needed to use in the below DKP keymove
SHIFT-2	 0;4;2L;4L;SHIFT-VOL-	     (key# $96) vcr std cable mode
   (0;4 puts VCR on ch4, 2L switches receiver input to VCR,
    4L switches TV input to VCR, shift-Vol- puts receiver in
    stereo mode)
SHIFT-4	 1;2;2L;SHIFT-4L;SHIFT-VOL-  (key# $99) VCR SAP mode
   (1;2 puts VCR on ch12, 2L switches receiver input to VCR,
    shift-4L makes TV screen black by forcing input from unassigned
    connection, and finally shift-Vol- puts receiver in stereo
    mode)
This, then, is the DKP keymove putting it all together
VCR	PIP_SWAP	<N/A>	TV	1208	$99 $96
where single single press uses shift-4 macro for SAP mode, and
double press uses shift-2 macro for standard mode. 
LKP can be built identically, except it would use setup code 1207.


URC 7800
------------------

LKP/DKP/DSM Combo Special Protocol: TV/1206, TV/1207, tv/1208
                                    Protocol ID=$01F9 (97 bytes long)

DEVICES

1.  DSM - both digits of the 4th byte are 0, do not change it 
    check Protocol > FF setting when adding this to IR

Upgrade code 0 = 14 B6  (TV 1206)
 F9 00 01 00
End

2.  LKP - first digit of the 4th byte is 1, do not change it
    duration=5 is the right digit of the 4th byte,
    it may be edited from 5 to any number 1 to F
    check Protocol > FF setting when adding this to IR

Upgrade code 0 = 14 B7  (TV 1207)
 F9 00 01 15
End

3.  DKP - first digit of the 4th byte is 2, do not change it
    duration=5 is the right digit of the 4th byte,
    it may be edited from 5 to any number 1 to F
    check Protocol > FF setting when adding this to IR

Upgrade code 0 = 14 B8  (TV 1208)
 F9 00 01 25
End


COMMON PROTOCOL - DO NOT ADD THIS PROTOCOL TO THE RDF FILE

Upgrade protocol 0 = 01 F9 (S3C8) LDKP+DSM-7800ext2(PB) (PB v3.11)
 00 00 12 A6 78 02 6B 54 18 03 19 4A 56 4A 0F F6 
 17 5C 37 1B 23 37 19 12 18 04 A6 C1 00 6B 0A 08 
 61 97 10 63 19 77 E6 78 02 AF F6 13 06 FB E9 76 
 7B 20 6B F6 18 05 8B E2 E4 01 78 56 7B 7F E6 F1 
 7F 6F 76 7B 80 EB 08 76 7B 20 6B F5 8D 80 18 F6 
 12 E7 A6 75 00 6B E1 A4 75 77 6B D8 2C 06 8D 13 
 F8
End


	



  This is the 18-Jan-02 test release of my second variant of
extender for a URC7800 (Cinema7).  I'd never keep version numbers
straight, so I'll use dates.

  This variant differs from the first variant in the handling of macros.

  The primary advantage of this extender is that it has much more room
for key moves and macros than the unextended remote.  It also lets you
have key moves and macros on any key other than SETUP.  The
unextended remote doesn't allow them on SLEEP or the device keys.  It
also has a more flexible feature for something like "punch through" on
the volume, pip, and transport key sets.

  The removed features (to keep my code small and simple) include.
1)  All functions of the SETUP key except as a shift.  (All setup must
be done with IR.EXE, not on the remote itself).
2)  All support for learned codes.
3)  The remote's internal SLEEP processing.  If the device you are
controlling has a SLEEP feature, you can send that code with whatever
key you want (including the SLEEP key).  If the device has no SLEEP
feature you can no longer use the remotes internal timer to simulate
one.
4)  Many other subtle timing features.  For example, the unextended
remote keeps the LED on as long as the key is pressed only for keys that
continue sending something.  It uses a fixed short flash for device
keys, etc. which do internal operations.  My extender keeps the LED on
as long as the key is held for most keys that do something.  It still
knows not to light the LED for a key that does nothing.
5)  Searching for an AdvCode override after finding a macro on the
same key.

Installation:

   Because the memory use is so different, it isn't practical to install
this extender into an existing configuration file.  Instead I provided
a base configuration and you can copy things from your old configuration
into this configuration using two copies of IR.EXE.  (See the
reinstallation section if you are placing an earlier extender that uses
the same memory layout).

1)  Take the 7800ex2.txt and the RDF file from this ZIP and place them in
the directory where you run IR.EXE.

2)  I assume you have already saved your Cinema7's existing
configuration in a file on your PC.  If you haven't done that, you
haven't done enough with JP1 yet to try an extender.  Try something else
first.

3)  If you have a lot of key moves or macros in your old configuration,
and you are comfortable editing hex, open both 7800ex2.txt and your old
configuration file in a text editor.  All your old key moves and macros
are in the memory range 01A through 0FF.  Copy that section from the old
configuration file to the section starting at 42A in 7800ex2.txt

4)  Open 7800ex2.txt with one copy of IR.EXE and open your old
configuration in another.  (If you did step 3, there will be a checksum
error that you can ignore).

5)  Look at the seven (0..6) device setup boxes at the top of the old
one and manually set the new ones to the same values.

6)  Look at any devices or protocols you have set up in the old one and
copy them to the new.  Do not change or delete the TV:1800 protocol 180
that is there to launch the extender.  You can copy the body of an
upgrade (device or protocol) by selecting EDIT on the old one and
highlighting and copying the hex;  Then select ADD in the new one and
paste it in.  You need to manually type in the ID.

7)  Look at the "Advanced Codes".  If you copied them in step 3, check
them.  Otherwise you need to enter new ones using the old ones as a
guide.

8)  Look at the initial 7 macros I defined for you.  Each of those
is on a device key and gives complete control to the associated device
index when you press a device key.  You should remove or change some of
the commands in those macros.  For example, your TV probably doesn't
have any T keys (described much later), so you probably want to remove
the T_TV command from the TV key's macro.

9)  Same as step 7, except for macros.

10) Save your work and shut down both copies of IR.EXE (because the OS
might be confused about which copy should have the right to access the
parallel port).

11) Restart IR.EXE.  Load your saved work.  Upload it to the remote.  As
with other extenders, there will be a signature error that you should
ignore each time you change between a normal and an extended
configuration.

12) You may want to press the TV key and hold for a moment to remind
yourself that in an unextended remote the LED goes out even if you don't
release the button.  Don't change selected device because step 13
requires TV, which is the default after reset.

13) Press the POWER key.  This starts the extender.

14) The initial state of the M, V, T, and P device indexes are all
random.  Before pressing any keys that send anything you should press
one or more keys on which you have device macros, until you have set
all of the M, V, T, and P indexes at least once each.  Assuming that
you used device keys for your device macros, you should notice that the
LED remains on as long as you hold the key, rather than going off as in
step 12.  This isn't a good or intended feature, but it does give you
an easy answer to the question of whether the extender is active.

15) Use your remote.  Good luck.  Adding the task of writing this
extender to my normal busy schedule meant I had no time for TV, so I
haven't used it yet.  (Testing is never as good a test as using).
Remember you can always reload your prior configuaration.

16) If there aren't already a bunch of comments in the JP1 group by
users of this extender, then post your comments there.  Even if you
don't have problems, questions or suggestions, posting comments is
important to help extender writers know what to do next and to help
other JP1'ers know what to try.
------------------------------------------------------------------------
Reinstallation:

  If you have already installed my first 7800 extender or the earlier
incorrect distribution of this extender, then you can install this one
using a text editor by replacing the lines "020:" through "0E0:" in
your .txt file with the corresponding lines from this file.  You will
get a checksum error from IR.EXE, which you should ignore.
------------------------------------------------------------------------
Definitions:

Device Types: 0 .. 5  0=Cable, 1=TV, 2=DVD, 3=VCR, 4=Audio, 5=CD

Device Indexes: 0 .. 6  0=CBL, 1=TV, 2=DVD, 3=VCR, 4=RCVR, 5=AUX, 6=CD

Setup numbers:  Those four digit numbers used to setup device keys in
an unextended remote.

Setup ID: The combination of a device type, with a setup number.

Current device index:  What you set by pressing a device key in the
unextended remote.  My extender uses M, V, T and P device indexes
instead.

Punch through device index:  A smarter (less flexible) version of what my
V device index does.

Fallback device index:  A smarter (less flexible) version of what my T
device index does.

V keys:  VOL+, VOL-, MUTE

T keys:  REW, PLAY, FF, PAUSE, STOP, REC

P keys:  PIP-ON/OFF, PIP-SWAP, PIP-MOVE

M keys:  All keys except the STEUP, V, T and P keys.

V, T, P and M device indexes:  What I use instead of a current device
index.

Advanced Code: A code assigned to a key using a "key move".

Defined Code: A code assigned to a key in a device upgrade or in ROM.
------------------------------------------------------------------------

SETTING DEVICE INDEXES:

   In an unextended remote, each press of a device key sets the current
device index, and each time doing so changes away from VCR or DVD, it
sets the fallback device index to the index changed from (vcr or dvd).

   In my extender, the device keys only have meaning if you assign
advanced codes or macros to them.  The concept of "current device index"
has no meaning.  The fallback device index may still matter and is never
changed while running the extender.  It defaults to VCR on reset.  You
could set it to DVD by pressing DVD, TV, POWER to initially launch the
extender, rather than just POWER.  However, reasonable use of the T
device index makes the fallback device index useless.

   In the RDF file I defined 28 extra key codes, V_CBL .. M_CD.  These
keycodes can only be used in macros.  Each one assigns a device index to
a set of keys.  V_TV assigns the device index TV to the V keys.  M_CBL
assigns the device index CBL to the M keys, etc.

POSITION OF MACRO DEFINITIONS IN THE CONFIGURATION FILE:

   Macros are mixed in with Advanced codes in the configuration.  In an
unextended remote the sequence doesn't matter.  If you have a macro and
an advanced code on the same key, the advanced code overrides the macro.

   In my extender, the sequence matters.  Whichever is first wins.  If
you want an advanced code to override a macro, you must make sure it is
earlier in the configuaration.  IR.EXE doesn't show you the relative
position of advanced codes and macros, so the process isn't obvious, but
if you move an advanced code up within its list and/or move a macro down
in its list, you can get them into the right relative sequence.

BEHAVIOR OF THE V KEYS:

1)  First it searches for an advanced code in the V device
index or for a macro.

2)  If punch through is enabled, and the V device index's device type is
the default type for that index, and { the punch through device index is
RCVR or AUX, or the V device index is neither RCVR nor AUX } then it
looks for a defined code for the punch through device index.  If it
fails to find one it does not go on to step 3.  (If it decides not to
look, then it does go on to step 3).  This is all too complicated, so
I suggest leaving punch through disabled.

3)  It looks for a defined code in the V device index.

BEHAVIOR OF THE T KEYS:

1)  First it searches for an advanced code in the T device
index or for a macro.

2)  It searched for a defined code in the T device index.

3)  If the T device is TV or CBL then it searches for a defined code in
the fallback device index.

BEHAVIOR OF THE M OR P KEYS:

1)  It searches for an advanced code in the appropriate index or for a
macro.

2)  It searches for a defined code in the appropriate index.

BEHAVIOR OF THE SETUP KEY:

   Outside a macro, it just sets a shift flag so that the next key
other than SETUP pressed will be shifted.  Pressing the SETUP key more
than once or longer than normal is no different than pressing it once.
Unlike the unextended remote, you don't need to press SETUP twice to
shift a digit key.

   Inside a macro, the SETUP key is just a phantom key that could be
assigned an advanced code.  It does not shift the next key.  You shift
keys within macros with the shift check box in IR.EXE.

   Outside a macro, a shifted key acts shifted only for advanced code
and macro search.  It is unshifted if that search fails and a defined
code search occurs.

   A shifted key inside a macro is shifted for all search.  If the
advanced code search fails then the defined code search will fail as
well because no defined codes are shifted.

BEHAVIOR OF MACROS

   Macros run faster than in an unextended remote.

   Macros are enabled within macros.  In a macro on an unextended remote,
if you use a key that is defined as a macro, it will ignore that definition
and use the "defined code".  In this extender it will switch to beginning
of the other macro allowing concatenated macros.  Note that macros are not
nested.  Any part of the "calling" macro after the key that invokes the
called macro is useless (it is not resumed when the called macro finishes).

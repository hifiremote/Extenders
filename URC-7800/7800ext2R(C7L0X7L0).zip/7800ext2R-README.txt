Cinema7 URC7800 and URC 6800 extender 2R

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
22-JAN-2007 first reconstructed source of ext2
  
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Original 7800ext2 version by John Fine(johnsfine at jp1)
Disassembled,documented and compared to the original by Bill Jackson(unclemiltie at jp1)
"R" in "2R" stands for reconstructed extender2

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Files in this zip

C7L0X7L0 (URC-7800_6800 Cinema Extender).rdf - current RDF
7800ext2R-empty.ir     - Starter file extender only
7800ext2R+SpFun.ir     - Starter file containing 2 special protocols                      
7800ext2R.hex          - hex file to use in IR's Extinstall
7800ext2R.asm  - assembly source
7800ext2R.bat  - batch file to assemble
7800ext2R.lst  - list file from current assembly
DSM-C7(7800)ext2(PB).txt  - Protocol Builder assembly of DSM
readMe-ex2.txt         - John Fine's original instructions - READ THIS !!!
7800ext2R-README.txt   - This file - see below for additional notes about this extender
==================================================================


 
This extender uses the standard extender RDF "C7L0X7L0 (URC-7800_6800 Cinema Extender).rdf"
File is attached, and current as of today.
Please check the files section for newer versions.

Two versions included in the zip file:
(1) 7800ext2R-empty.ir - is a totally empty file, just the extender is in.
Double click or open in IR, add devices and protocols.

(2) 7800ext2R+Pause+DSM.ir - is the same file with official Pause and DSM devices.
Double click or open in IR, add devices and protocols.

To add extender to an existing 7800 upgrade, use IR's Extinstall to merge the .hex file in.

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Description of two special protocols included in the 7800ext2R+SpFun.ir file
These protocols are added. They are NOT part of the assembly.

(1) DEVICE SPECIFIC MACRO

Macro for a specific device rather than the normal, global macro.
Unlike in newer extenders, this DSM works with just one key.
Create a macro on some phantom or shift-key that you normally don't press.
Use that key as a parameter to the DSM keymove on the Special Function tab.

DSM-C7(7800)ext2(egd).txt

Upgrade code 0 = 1C 4F (TV/1103)				
 FC 00 01				
End
Upgrade protocol 0 = 01 FC (S3C8) DSM-C7(7800)ext2 (PB v3.11)
 00 00 01 08 61 0A 08 A6 62 00 EB 0D E6 62 01 18 
 03 97 10 63 09 61 E6 78 02 AF
End


(2) PAUSE

Use when delay between signals is needed.
Assign pause to a shift ot phantom button on the Special Protocols sheet
Enter pause value to use, in hex. Use the bound key in another macro where pause is needed.
Rough timing is 1sec for every $10, 15.4 sec for $FF. 

Upgrade Code 0 = 1C 50 (TV/1104) keymap-master Device Upgrade (KM v9.06)
 FB 00 01                                       
End
Upgrade Protocol 0 = 01 FB (S3C8) Pause Protocol (Special) (KM v9.06)
 00 00 01 E4 03 C2 C6 C0 00 00 0A FE 1A FC 2A FA
 AF
End

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
BASIC FEATURES:
===============

  You can put a Macro or KeyMove on any key.
  You have room for lots more KeyMoves and Macros.
  Macros can be Nested.
  Macros are fast.
  Very flexible device selection.
  Control of device displayed on LCD.
  Improved (very different) Fav list processing.
  Configurable backlight timer.
  Included special protocols for:
    Pause, Device Specific Macros, 
    ToadTog, Long/Double Key Press

  No logical device button support.
  No Learned signal support.
  No Scan support.
  No internal (to the remote) Sleep timer.
  No direct keying of EFC codes on the remote.
  No long-press-setup functions

INSTALLATION AND ACTIVATION
===========================

  See documentation in Install.txt

SPECIAL PROTOCOLS
=================

  This extender includes the following special protocols:

  MISC/1103, portocol 1FC = Device specific Macro
  MISC/1104, protocol 1FB = Pause
  MISC/1106, protocol 1F9 = Long/Double Key Press
  MISC/1800, protocol 181 = ToadTog

  See documentation for details on each individual protocol.
  (The Pause protocol is described in the FAST MACROS section in
  this document.)


DEVICE SELECTION:
=================

  There is no normal device selection.  There is no VPT.  There is no
Transport Punch Through.  There is no Home Theater Mode.

  Instead there is a device selection mechanism by key set that has a
superset of the power of all the above;  But you must define macros to use
and customize it.

  The device keys and HT key have no built in meaning.  You must define
macros to have any device selection at all.

  There are 49 commands that can be used in macros to control device
selection.  Each command specifies the key set and the Device Index that will
be used for keys in that set.  For example M_TV says the TV device will be
used for keys in the "Menu" set.

  There are 6 Key sets: Menu, Channel, Volume, Transport, Other and
Temporary(X).  There are 8 Device Indexes: TV, VCR, CBL, SAT, CD, DVD, AUX, 
and AUD.  There is one additional command X_Cancel.

  There are also 8 LCD commands that can be used in macros to control the
LCD display.  Each command changes the LCD to display the device name
associated with the specified device.  There is one additional command
LCD_MYSYS, which sets the LCD display "MySys".

  To achieve simple device selection (no VPT, TPT or HT) and set the LCD,
you would put a 7 command macro on each device key, for example the TV 
device key would have the macro:
P_TV; M_TV; C_TV; V_TV; T_TV; O_TV; LCD_TV

  The 2116 has 8 physical device keys and 7 logical device keys;  But the 
extender only supports the physical device keys.  You can use any keys you 
want for the device selection macros (and you can use device keys for other 
purposes).

  To achieve VPT, replace the V_ command within the macro for each device
that should have VPT enabled with the command from the device to which VPT
should be set.  For example, to enable TV VPT on your VCR, the VCR key
macro might be:
P_VCR; M_VCR; C_VCR; V_TV; T_VCR; O_VCR, LCD_VCR

  If you want full VPT (same V_ selection in all device selection macros) you
can save some macro memory by omitting all the V_ commands.  You can set the
initial V device using IR.  That remains as the V device as long as no V_
commands specify a different V_ device.

  To achieve crude TPT (such as most of the UEIC remotes) replace the T_
command within the macro for each device that should have TPT enabled with
T_VCR.  For example, your TV key macro might be:
P_TV; M_TV; C_TV; V_TV; T_VCR; O_TV, LCD_TV

  To achieve dynamic TPT (similar to the URC7800).  Omit the T_ command from
the macro for each non Transport device and include it in the macro for each
transport device (VCR, DVD etc.).  When you select a non transport device,
the T keys will all remain associated with whatever transport device was
most recently selected.

  To achieve Home Theater, put a device selection macro on the Home Theater
key.  Include specific M_, C_, V_ and T_ commands to select your HT
settings.  To duplicate the UEIC version of HT mode, omit the O_ command from
the HT macro so that the O keys remain associated with whatever device they
were associated with before.  (UEIC HT mode seems to support the Power key
only as a special macro.  With this extender the Power key is either an
ordinary macro or an ordinary O key, whichever you programed it as).

  Shifted keys all go into the key set containing their unshifted
counterpart.  For example SHIFT-Stop is in the T set.  Phantom keys are in
the O set.  Device keys are in the O set;  But most people will put macros
on device keys.  If a key is a macro, it doesn't matter which set it is in.
The set only matters for KeyMoves and for keys defined by setup code.

Temporary Device Selection:
---------------------------

  Within a macro, you often want to issue a key to a specific device
regardless of the previous device selection and without disturbing that
previous device selection.  You use X_ commands to do that.  For example,
the sequence
X_TV; 0; 3
in a macro would send the 0 and 3 keys to the TV regardless of the previous
device selection.

  The X_ selection is automatically canceled when the outermost macro (see
nested macros) completes.  If the above example were intended for use as a
top level macro, there would be no need for it to explicitly cancel its X_
command.  If the above example were in a general purpose macro that might
be called by other macros, you probably should change it to:
X_TV; 0; 3; X_Cancel

  While an X_ command is active, it applies to all keys.  The usual division
into Menu, Channel, Volume, Transport and Other doesn't apply.

NESTED MACROS:
==============

  You can nest macros to any depth.  Any key that is a macro when used from
the keyboard is the same macro when used inside a macro.

  This is very different from the base remote and from other extenders.  Pay
careful attention to this detail when converting a configuration for use
with this extender.  There is no protection from infinite loops when a macro
nests into itself.

  Many people have used the fact that macros don't nest (in the basic remote)
for things like a Power macro that uses the normal Power key.  Find and
change anything like that in your configuration (see "Cloaking with Shift").

  There is a 28 byte macro buffer (the same 15 byte buffer used by SelNestMac
on other remotes).  That doesn't change the limit on an individual macro
(still 15 commands) nor does it set a limit on the total number of
commands executed by one macro (virtually unlimited).  It limits the number
of commands "pending" at any one moment.  If you exceed that limit, you
will the the error message "MEMFULL" on the LCD.  Note:  You will not get
this error message if you exceed the macro buffer while using special
special protocols such at ToadTog, DSM, or LDKP.

  To understand "pending" commands, imagine 4 macros, A, B, C, and D:
A = B; C; D
B = 1; 2; 3
C = 4; B; 5; 6
D = 7; 8; 9
when you press A, you get 1 2 3 4 1 2 3 5 6 7 8 9, which is 12 commands, but
in executing those 12 commands, there were never 12 commands "pending".
When the extender processes the first B there are 5 command pending:
1; 2; 3; C; D;
Later it process the C and there are again 5 commands pending:
4; B; 5; 6; D
When it processes the second B there are 6 commands pending
1; 2; 3; 5; 6; D
The whole 12 commands are sent with a maximum of 6 ever pending.  You should
be able to design ridiculously long macros without ever hitting the limit of
32 pending commands.

FAST MACROS:
============

  I reduced both the hold time and the delay time for commands in a macro.  I
think that is necessary to make macros useful.  There are situations in which
you need to add back some hold time or delay time.

  For delay, you can use:

1)  For a very small delay, use a redundant device selection command.  If you
know that an X_ selection won't be in use at the relevant point in macro
execution, you can use a redundant X_Cancel as a tiny delay.  If you know or
use any other device selection, you can use it again as a delay.  For example,
if you want a delay between digits in the macro "C_TV; 0; 3" you could use
"C_TV; 0; C_TV; 3".

2) For a slightly longer delay, use an undefined key code. The actual amount
of delay will depend on the number of items in your KeyMove and Macro area.
For example, if you have no KeyMove or Macro for shift-X_Cancel, you could
use shift-X_Cancel as a delay.

3) For a long delay, use a KeyMove connected to the Pause protocol (MISC/1104).
The hex command is the amount of delay from 01 (smallest) to FF.  

  For adding back hold time, I haven't provided anything in this version of
the extender, except for the last step of a macro.

HOLDING LAST STEP OF A MACRO:
=============================

  If the last step of a macro transmits a signal, and you held down the
original key that started the macro through the entire macro execution,
the extender will continue the last signal while that button is held,
just as the remote normally does for a signal that is the only action of
a button.

  This feature acts the same for ToadTogs and DSMs as for ordinary macros.
It acts the same for mini-macros (from a Fav list) as well, except that all
mini-macros are really exactly 3 commands long, rather than being 1 to 3
commands long as they seem.  IR.EXE pads any shorter mini-macros with NULL
commands to make them 3 commands long.  If a mini-macro is less than 3
commands, its last command is a NULL command, so holding the key won't make
a difference.  If you want holding the key to make a difference, try padding
the beginning or middle of the mini-macro with redundant device selection
commands rather than letting IR.EXE pad the end with NULL commands.

  In rare cases, you want to defeat this feature and avoid having the last
step of a macro continued if the user holds the key.  You can most easily do
that by adding an X_ command to the end.

SHIFTED KEYS:
=============

   Pressing the Setup key causes the next key to be "shifted".

   The shift only affects the lookup of the key as a KeyMove or Macro.  If no
KeyMove or Macro is found for a shifted key, the remote then checks whether
the unshifted version of the key is defined by the setup code.

   The Setup key only acts as a shift key when used from the keyboard.  When
used in a macro the Setup key is just an ordinary (O set) key.  When used
from the keyboard the Setup key is both a shift key and an ordinary key, so
you can get some confusing or interesting (depending on your intent)
behavior by defining a KeyMove or Macro for the Setup key.

   To use a shifted key in a macro use the "Add Shift" option of IR;  Do not
try to make it shifted by preceding it with the Setup key.

Changing the Shift Key:
-----------------------

   In the General/Other_Settings pane of IR.EXE you can configure shift to be
a different key or two keys.

"Shift Button Keycode" defines the primary shift key.  The value is displayed
as a decimal number.  The default is 2, which is the Setup key.  You can
change it to any key you prefer.  If you look up the keycode in KeyCodes.htm,
that value will be in hex.  You can type a hex value in the settings area by
prefixing it with "$".  IR will change it to the decimal value.  For example,
if you type the value in as $36 and IR shows it as 54.

Cloaking with Shift:
--------------------

   If you want to define a macro for a key (such as Power) but also use that
key as defined by the setup code (probably in that macro) the trick is to
use the shifted version of the key.  For this to work, you must not define
a KeyMove for the shifted key (in the current device index) nor define a
macro for it.  Then put shift-Power inside the Power macro.  When the
extender fails to find a KeyMove or macro for shift-Power, it looks in the
setup code for a definition of Power and finds the one that you couldn't
access directly because the macro is in the way.

KEY SETS:
=========

T  =  Rew, Play, FFwd, Rec, Stop, Pause
V  =  Vol+, Vol-, Mute
C  =  Ch+, CH-, digits, Enter, Last, Sleep, Info, TV/Video
M  =  Menu, Guide, Up, Down, Left, Right, Select, Exit
O  =  Pip, Freeze, Swap, Move, +100
O  =  P{Setup}, {Light}, Power, Fav/Scan, device keys, phantoms

FAV/SCAN:
=========

   You can use IR to define a Fav list of up to 15 mini-macros of up to 3 keys
each.  IR handles all 15 mini-macros together as one line item in its Scan/Fav
tab.  Within that line item, the mini macros are delimited by "{pause}".  IR
also allows you to create additional whole Fav lists;  But the remote can't
use them.

   The extender operates the Fav list differently than the unextended remote
in three important aspects:

1) The extender executes just one mini-macro each time you press the Fav key
(advancing through them circularly).  The unextended remote will continue
executing the mini-macros with 3 second pauses in between until you press
another key to stop it.

2) The extender will switch the temporary device index to equal the Fav
device index whenever it starts a Fav mini-macro.  The unextended remote
only recognizes the Fav list if the device index already matches the Fav
device index.

3) The unextended remote will do a Scan operation instead of a Fav list
operation whenever the Fav key is used in a device index that doesn't match.
The extender will never do a Scan operation.  To have it do something other
than a Fav operation on certain device indexes, you must define a Key Move
for Fav for each such device index.  (The Key Move will only override the
Fav List if IR.EXE puts the key move earlier within the
KeyMove/Macro/FavList pool than it puts the FavList.)


BACKLIGHT AND SHIFT TIMER:
==========================

  When the backlight is enabled, it comes on at the later of the end of each
operation or the release of the key that started the operation.  It then stays
on for up to ten seconds or until you press another key.

  You can change that ten second timer to another value.  Multiply the number
of seconds you want by 7.6 and round to the nearest integer.  Scroll the
"Other Settings" pane of IR down to show "Backlight timer" and type the
computed value there.  For example, if you want 12 seconds, you would compute
12 * 7.6 = 91.2 and enter the value 91.  The value must be in the range 1 to
255.

  Whether or not the backlight is enabled, the extender also uses the same
timer to cancel shift operations.  After you release the shift key, you have
only the length of time programmed as the backlight timer to press the next
key in order for that key to be shifted.


RDF FILES:
==========

  The enclosed RDF file "RSL1RSX1 (RS 15-2116 Extender1).rdf" is needed
  in the directory where you run IR.EXE to edit an eeprom image of the
  extender.

  The above rdf as well as some "15-2116" rdf files are required in the
directory where you run the ExtInstall program.

  In the past, as newer versions of IR.EXE have been released, they have been
bundled with updated versions of rdf files for various extenders.  If you use
this extender with a newer version of IR, it might include updates to the rdf
files that are included with this extender.  Such updates would have names
whose first 8 characters exactly match the first 8 characters of the rdf being
replaced (other parts of the name may be different).  If IR includes such
updates, you should probably use them instead of the rdfs included here.  If
IR is older than this extender or does not include such updates, then the
rdf files included hereshould be used.

TROUBLE SHOOTING:
=================

  This is a complicated extender that may still have some bugs in it, and it
lets you define very complex behaviors for your remote, which will probably
have errors on first try.

  The major method of trouble shooting is to break complex operations down
into their parts and see if the parts work individually.

Example:  You have a macro that does some device selection and does two
phantom codes and each phantom code does a ToadTog and it doesn't work.
Assign those two ToadTogs to pressable keys (temporarily for trouble
shooting).  If necessary, define some simple macros to duplicate the
device selection of the complex macro.  Test the individual pieces of the
complex macro and see which work.

Example:  You have a ToadTog that doesn't work:  Make a simple macro or
DSM out of each command list of the ToadTog.  Test the two sequences that
way.

  A moderate fraction of macro, DSM and ToadTog problems are due to one of
two timing issues:

1)  The extender reduces (to the minimum value) the duration of signals which
are not the very last step in its macro buffer and signals which are processed
after the user has released the key that started the whole operation.
  If you suspect you have a duration problem, you should confirm it with two
tests.  Put the single function on a pressable key and press and hold that
key.  If that doesn't work, something more basic than a duration problem is
wrong.  Put a macro or DSM on a pressable key that is just the problem
function followed by an X_Cancel.  When you press that key, the function is
not last, so the duration will be minimum.  If that introduces the failure
you know it's a duration problem (there are then a variety of approaches to
fixing it).

2)  The extender reduces the time between signals within any automated
sequence of signals.  If functions work when manually sent in sequence, but
don't work when automatically sent in sequence, and you determine it's not a
duration problem, then it's time to try delays.  Define a KeyMove for a
moderately long use of the pause protocol.  Insert that before and/or after
the problem function(s) in your sequence.  If that fixes it, you've confirmed
that it is a timing problem and you can then experiment to fine tune the
correction to fix the problem with minimum increase in the time it takes the
whole operation to complete.
   Rarely, a device is sensitive to any signal at all right before or right
after its signal.  In those cases, the best you can do is find the smallest
added delay that fixes the problem.
   More often, a device just needs time to do the operation you gave it before
it is ready for the next.  In a complex macro, you may have an alternative to
adding delay.  If you're sending two commands to device A, then one command to
device B, try sending the command to device B in between the two commands to
device A.  That probably takes one or two extra X_ commands beyond doing it the
simple way, but probably takes less total execution time than simply adding
delay.

*BASIC FEATURES:  urc-7562B01 extender v0.1
===========================================

  You can put a Macro or KeyMove on any key.
  You have room for many more KeyMoves and Macros.
  Macros can be Nested.
  Macros are fast.
  Very flexible device selection.
  Included special protocols for:
    Pause, Device Specific Macros, 
    ToadTog, Long/Double Key Press

  No Learned signal support.
  No Scan support.
  No direct keying of EFC codes on the remote.
  No long-press-setup functions

Note. Although there is an apparent decrease in available space for device 
upgrades due to the additional special protocols, this is not the case since
IR allows for device and protocol upgrades to be loaded into the KeyMove and
Macro area, which is significantly larger.


INSTALLATION AND ACTIVATION
===========================

See separate installation instructions (Install.txt).

DEVICE SELECTION:
=================

The device selection mechanism supports the following:
  6 physical device indexes: 
    TV, VCR, SAT, CD, DVD, and AUD
  6 key sets:  
    Menu, Channel, Volume, Transport, Other and PIP

There is no normal device selection. There is no VPT. 

Instead there is a device selection mechanism by key set that has a
superset of the power of all the above; But you must define macros to use
and customize it.

The device keys and HT key have no built in meaning. You must define
macros to have any device selection at all.

There are 6 DEV_ commands that can be used in macros to temporarily 
set the active device. There is a separate command for each of the
physical devices
Each command specifies the Device Index that will be used. For 
example, DEV_TV sets the TV device to the active device. DEV_ 
commands apply to all keys, but only last until the outermost macro 
(see Nested Macros) completes or another DEV_ command is encountered.
DEV_ commands do not permanently set the active device. See 
Temporary Device Selection for more details.

There are 6 SET_xxx_KEYS commands that can be used in macros to tie
the current active device (as specified by a DEV_ command) to a particular
key set. Once a key set is tied to a device, it remains tied to that 
device until the same SET_xxx_KEYS command is used to tie it to another
device. Keys bound by a SET_xxx_KEYS command remain bound, even outside
of the macro.

For example, to set the transport keys to the VCR device, you
would use the macro "DEV_VCR; SET_TRANS_KEYS". This would set 
the transport keys to the VCR device until another macro set
them to something else.

To achieve simple device selection (no VPT or HT), you would put a 7
command macro on each device key, for example the TV 
device key would have the macro:
  DEV_TV; SET_TRANS_KEYS; SET_VOL_KEYS; SET_CHAN_KEYS;
    SET_MENU_KEYS; SET_OTHER_KEYS; SET_NUM_KEYS

To achieve VPT, replace the SET_VOL_KEYS command within the macro for each 
device that should have VPT enabled with the commands to set the VPT keys to 
the desired device. For example, to enable TV VPT on your VCR, the VCR key
macro might be:
  DEV_TV; SET_VOL_KEYS; DEV_VCR; SET_TRANS_KEYS; SET_CHAN_KEYS;
    SET_MENU_KEYS; SET_NUM_KEYS; SET_OTHER_KEYS

If you want full VPT (same VOL selection in all device selection macros) you
can save some macro memory by omitting all the SET_VOL_KEYS commands. 
You can set the initial VOL device using IR. That remains as the VOL device 
as long as no SET_VOL_KEYS commands specify a different VOL device.

To achieve crude TPT (such as most of the UEIC remotes) replace the 
SET_TRANS_KEYS command within the macro for each device that should have 
TPT enabled with command sequence to set the transport keys. For example, 
your TV key macro might be:
  DEV_VCR; SET_TRANS_KEYS; DEV_TV; SET_VOL_KEYS; SET_CHAN_KEYS;
    SET_MENU_KEYS; SET_NUM_KEYS; SET_OTHER_KEYS

To achieve dynamic TPT (similar to the URC7800). Omit the SET_TRANS_KEYS
command from the macro for each non Transport device and include it in the 
macro for each transport device (VCR, DVD etc.). When you select a non 
transport device, the transport keys will all remain associated with whatever 
transport device was most recently selected.

To achieve Home Theater, put a device selection macro on the Home Theatre
key. Include specific DEV_ and SET_xxx_KEYS to select your HT settings. 
To duplicate the UEIC version of HT mode, omit the SET_OTHER_KEYS command from
the HT macro so that the Other keys remain associated with whatever device they
were associated with before. (UEIC HT mode seems to support the Power key
only as a special macro. With this extender the Power key is either an
ordinary macro or an ordinary Other key, whichever you programmed it as).

Shifted keys all go into the key set containing their unshifted
counterpart. For example SHIFT-Stop is in the Transport set. Phantom keys 
are in the Other set. However, see the note regarding Menu and Magic modes.

Device keys are in the Other set; But most people will put macros on device 
keys. If a key is a macro, it doesn't matter which set it is in. The set 
only matters for KeyMoves and for keys defined by setup code.


Temporary Device Selection:
===========================

Within a macro, you often want to issue a key to a specific device
regardless of the device the key is tied to and without disturbing that
relationship. You can use the DEV_ commands to do that. 
For example, the sequence
  DEV_TV; 0; 3
in a macro would send the 0 and 3 keys to the TV regardless of the device
tied to the 0 and 3 keys.

The DEV_ selection is automatically cancelled when the outermost macro 
(see nested macros) completes. 

There is also DEV_Cancel command which will cancel the current DEV_
command in a macro. If the above example were intended for use as a
top level macro, there would be no need for it to explicitly cancel its DEV_
command. If the above example were in a general purpose macro that might
be called by other macros, you probably should change it to:
DEV_TV; 0; 3; DEV_Cancel

While a DEV_ command is active, it applies to all keys. Any assignments made
by the SET_xxx_KEYS commands are ignored.


NESTED MACROS:
==============

You can nest macros to any depth. Any key that is a macro when used from
the keyboard is the same macro when used inside a macro.

This is very different from the base remote and from other extenders. Pay
careful attention to this detail when converting a configuration for use
with this extender. There is no protection from infinite loops when a macro
nests into itself.

Many people have used the fact that macros don't nest (in the basic remote)
for things like a Power macro that uses the normal Power key. Find and
change anything like that in your configuration (see "Cloaking with Shift").

There is a 21 byte macro buffer (the same 15 byte buffer used by SelNestMac
on other remotes). That doesn't change the limit on an individual macro
(still 15 commands) nor does it set a limit on the total number of
commands executed by one macro (virtually unlimited). It limits the number
of commands "pending" at any one moment. 

To understand "pending" commands, imagine 4 macros, A, B, C, and D:
  A = B; C; D
  B = 1; 2; 3
  C = 4; B; 5; 6
  D = 7; 8; 9
when you press A, you get 1 2 3 4 1 2 3 5 6 7 8 9, which is 12 commands, but
in executing those 12 commands, there were never 12 commands "pending".
When the extender processes the first B there are 5 commands pending:
  1; 2; 3; C; D;
Later it process the C and there are again 5 commands pending:
  4; B; 5; 6; D
When it processes the second B there are 6 commands pending
  1; 2; 3; 5; 6; D
The whole 12 commands are sent with a maximum of 6 ever pending. You should
be able to design ridiculously long macros without ever hitting the limit of
32 pending commands.


FAST MACROS:
============

Both the hold time and the delay time for commands in a macro have been reduced.
There are situations in which you need to add back some hold time or delay time.

  For delay, you can use:

1)  For a very small delay, use a redundant device selection command. If you
know that a DEV_ selection won't be in use at the relevant point in macro
execution, you can use a redundant DEV_Cancel as a tiny delay. If you know or
use any other device selection, you can use it again as a delay. For example,
if you want a delay between digits in the macro "DEV_TV; 0; 3" you could use
"DEV_TV; 0; DEV_TV; 3".

2) For a slightly longer delay, use an undefined key code. The actual amount
of delay will depend on the number of items in your KeyMove and Macro area.
For example, if you have no KeyMove or Macro for xs_Phantom1 you could
use xs_Phantom1 as a delay.

3) For a long delay, use a KeyMove connected to the Pause protocol (VCR/1104).
This is described below under the Special Protocols sections.

In this version of the extender there is no mechanism for adding back hold time.


HOLDING LAST STEP OF A MACRO:
=============================

If the last step of a macro transmits a signal, and you held down the
original key that started the macro through the entire macro execution,
the extender will continue the last signal while that button is held,
just as the remote normally does for a signal that is the only action of
a button.

This feature acts the same for ToadTogs and DSMs as for ordinary macros.

In rare cases, you want to defeat this feature and avoid having the last
step of a macro continued if the user holds the key. You can most easily do
that by adding the DEV_CANCEL command to the end.


SHIFTED KEYS:
=============

Pressing the Setup key causes the next key to be "shifted".

The shift only affects the lookup of the key as a KeyMove or Macro. If no
KeyMove or Macro is found for a shifted key, the remote then checks whether
the unshifted version of the key is defined by the setup code.

The Setup key only acts as a shift key when used from the keyboard. When
used in a macro the Setup key is just an ordinary (Other set) key. When used
from the keyboard the Setup key is both a shift key and an ordinary key, so
you can get some confusing or interesting (depending on your intent)
behaviour by defining a KeyMove or Macro for the Setup key.

To use a shifted key in a macro use the "Add Shift" option of IR; Do not
try to make it shifted by preceding it with the Setup key.


Cloaking with Shift:
====================

If you want to define a macro for a key (such as Power) but also use that
key as defined by the setup code (probably in that macro) the trick is to
use the shifted version of the key. For this to work, you must not define
a KeyMove for the shifted key (in the current device index) nor define a
macro for it. Then put shift-Power inside the Power macro. When the
extender fails to find a KeyMove or macro for shift-Power, it looks in the
setup code for a definition of Power and finds the one that you couldn't
access directly because the macro is in the way.


KEY SETS:
=========

NUM	=  digits (0-9), +10{-/--}, AV{Exit_20}
Trans	=  FFWD{Expand}, PAUSE{Hold}, PLAY{TextOff}, REC{Yellow}
           REW{TextOn}, STOP{Green}, SP/LP{Red}, AUTO{Blue}
Vol	=  Vol+, Vol-, Mute
Chan	=  Ch+, CH-
Menu	=  Menu, Up, Down, Left, Right
Other	=  Power, device keys, phantoms


Menu Mode:
==========

The unextended remote has special processing for its "Menu mode".
In Menu mode the xShift continues to be applied to the Mute and AV buttons
allowing them to be used as Select and Exit functions when using Menus
without the need to press the Menu key again. The Menu mode is exited by 
either: Pressing the Exit (AV) key, pressing a device key or a timeout 
(approx. 10s) between key presses, i.e. Menu mode remains in effect
whilst other keys, such as the arrow and digit keys, are being used.
The extender changes this behaviour in several significant ways through
the "Other Settings" on the IR General tab:
 1) It can be disabled completely. Pressing Menu will just act as an 
    xShift to the next key only, as well as performing any function
    assigned to the Menu key itself.
 2) It can be extended so that the Exit (AV) key does NOT exit Menu
    mode. This is useful for multi-layered menu systems. A timeout or
    device key still exits Menu mode.
 3) As the VPT function is replaced by the SET_VOL_KEYS, the xShifted Mute
    key would be in the VOL key set, which may not be the desired behaviour.
    Therefore within IR a key can be specified to use instead to determine
    the pseudo key set and the appropriate device upgrade to use instead.
    The default is AV key and so the same device upgrade will be used for
    both the Exit (AV) and Select (Mute) keys.


Magic Mode:
===========

In addition to operating as a shift for the next key press the unextended 
remote has special processing for its "Magic mode".
In Magic mode the Shift continues on the Vol+, Vol-, Ch+ and Ch- keys, and
these are often labelled Color+/- and Bright+/-. In the extender this 
facility may be disabled via IR. If enabled then, when in Magic mode, the 
Shifted Vol+/Vol- keys can be treated as though they are in a different key
set to that of the unshifted keys. In IR specify a key code to be used to
determine their pseudo key set and the appropriate upgrade.
The default is the CH+ key and so, when in Magic mode, the same device 
upgrade would be used for all 4 shifted keys.


RECORD SAFETY:
==============

The unextended remote has a Record safety feature requiring the user to press
the record button twice for device types VCR, DVD, CD and AUD to prevent
accidental recording. This can be overcome by changing the device type of an
upgrade to SAT or TV, however, for built-in upgrades this is not possible.
The extender allows this feature to be disabled for all device types via an
entry on the General tab of IR.


SPECIAL PROTOCOLS:
==================

This extender includes the following special protocols:

  VCR/1103, protocol 1FC = Device specific Macro
  VCR/1104, protocol 1FB = Pause
  VCR/1106, protocol 1F9 = Long/Double Key Press
  VCR/1800, protocol 181 = ToadTog

The special protocols are enabled in IR via the "special protocols" tab. 
See additional documentation below on how to use these protocols.

Note. If the LKP protocol provided in this thread ...
	http://www.hifi-remote.com/forums/viewtopic.php?t=2489
is currently used it may be replaced by the LDKP included with the 
extender or replaced by the following protocol.

Upgrade protocol 0 = 01 82 (S3C8)  Simple LKP (7562B01 Extender)
00 00 12 A6 7E 83 3B 16 E4 03 4A F6 06 BF F6 30 
11 FB 08 76 6F 20 6B F6 E4 05 04 82 7E 04 AF 
End


PAUSE Protocol:
===============

This special protocol is packaged as an upgrade protocol (1FB) and an upgrade
device (VCR/1104) that are automatically installed when you install the 
extender. If you don't need this protocol and want to conserve upgrade memory, 
you can delete those upgrades.

The special protocols tab in IR (v8+) will allow values from about 0.06s 
to 16s. For earlier versions of IR the one byte hex command is the amount of 
delay from 01 (smallest) to FF in increments of 0.06s.

Note. In the "Protocol Upgrades.txt" file there is a modified version of the 
Pause protocol that can be interrupted by pressing a key on the remote.
Macros will continue at the step following the pause.


Device Specific Macro:
======================

This special protocol is packaged as an upgrade protocol (1FC) and an upgrade
device (VCR/1103) that are automatically installed when you install the 
extender. If you don't need this protocol and want to conserve upgrade memory, 
you can delete those upgrades.

This protocol allows you to build a macro that is only loaded and executed for 
a specific device and will allow you to build different macros on the same key
that are executed for specific devices. 

To use DSM, use the Special Protocols tab and select DSM in the parameters 
pane.


Long/Double keypress:
=====================

This special protocol is packaged as an upgrade protocol (1F9)
and an upgrade device (VCR/1106) that are automatically installed
when you install the extender. If you don't need this protocol
and want to conserve upgrade memory you can delete those upgrades.

This special protocol allows you to execute either one of two key
sequences based on two different key press patterns:

  Long Key Press: Shorter vs. Longer than the specified duration.

  Double Key Press: Single vs. Double press. (A double press
      is two consecutive key presses within the specified duration.)

Setup
------

In IR, Select the "Special Protocol" tab

1:  In the Bound Key section, select the bound device and key  

2:  In the Parameters pane, select LKP or DKP and the duration as 
    described above.

3:  In the Macro definition, add the keys for the Short/Long or
    single/double key presses.

Durations are expressed as digits 1 through 15 and have durations
of approximately:

      1 ... 0.3 sec		      2 ... 0.6 sec
      3 ... 0.9 sec		     10 ... 2.8 sec
     15 ... 4.3 sec


ToadTOG - build toggles and discrete codes
==========================================

The extender includes a ToadTog protocol. It is packaged as an upgrade 
protocol (181) and an upgrade device (VCR/1800) that are automatically 
installed when you install the extender. If you don't need a ToadTog 
protocol and want to conserve upgrade memory you can delete those upgrades.

ToadTog lets you construct toggle functions from discrete functions, and/or
construct discrete functions from toggle functions, and/or track the state of
device toggles so that other functions may be sent differently depending on
that state. It does this by testing the state of a toggle (see below) and 
then sending a sequence of keystrokes depending on the state. All of these 
are  configurable through the IR special protocols tab.

There are 8 individually selectable toggles that retain state of the 
devices being controlled. You will need to use one of these for each toggle 
that you will be using in the remote.

Each ToadTog entry can test or change the state of the toggle in one of
four ways AFTER the command sequence has been loaded into the macro buffer
for processing. These are:

    Toggle	toggle the state of the toggle bit
    test only	test only, do nothing to the state of the toggle bit
    force off	force the toggle to an off state
    force on	force the toggle to an on state

IR allows you to build your toggles or discrete commands by defining key
sequences that will be loaded and processed based on the state of the toggle
and then allowing you to set the state of the toggle. The examples below show
how to build a discrete on/off from only a power toggle. Similar toggles can
be used to create a power toggle from discrete's, or a discrete device
selection command. 

Discrete on/off

In IR, you select a device and a key for the new functions that you will
enable. In this example we use DiscreteOff/DiscreteOn. Next select an unused
toggle (toggle 1). For the discrete off command, use the "force off" condition
that will tell the remote that after the command has executed the device will
be in the "off" state. Next, define the sequence of keys that will execute with
the device in the "already on" state and in the "off-on" state. If the device 
is already on, we want to send a "power toggle" command to the device to turn 
it off. If the device is on the off state, we want to send no commands to it.

Similarly, for the discrete on, we will use the same toggle, select the
"force on" condition, and send a power toggle when the device is off and 
nothing when it is on. 
When you are finished you should see something like this:

VCR  DiscreteOff  ToadTog(1,Forceoff) on/off:power, already off: <blank> 
VCR  DiscreteOn   ToadTog(1,Forceon)  already on:<blank>, on/off:power


RDF FILES:
==========

  The enclosed RDF file "EM6XEM61 (URC-7562-B01 Extender 1).rdf" is needed
  in the directory where you run IR.EXE to edit an eeprom image of the
  extender.

The above rdf as well as the "EM60EM60 (URC-7562-B01 One for All).rdf" file 
is required in the directory where you run the ExtInstall program.

In the past, as newer versions of IR.EXE have been released, they have been
bundled with updated versions of rdf files for various extenders. If you use
this extender with a newer version of IR, it might include updates to the rdf
files that are included with this extender. Such updates would have names
whose first 8 characters exactly match the first 8 characters of the rdf being
replaced (other parts of the name may be different). If IR includes such
updates, you should probably use them instead of the rdfs included here. If
IR is older than this extender or does not include such updates, then the
rdf files included here should be used.

TROUBLE SHOOTING:
=================

This is my first extender and may still have some bugs in it, and it
lets you define very complex behaviours for your remote, which will probably
have errors on first try.

The major method of trouble shooting is to break complex operations down
into their parts and see if the parts work individually.

Example:  You have a macro that does some device selection and does two
phantom codes and each phantom code does a ToadTog and it doesn't work.
Assign those two ToadTogs to pressable keys (temporarily for trouble
shooting). If necessary, define some simple macros to duplicate the
device selection of the complex macro. Test the individual pieces of the
complex macro and see which work.

Example:  You have a ToadTog that doesn't work:  Make a simple macro or
DSM out of each command list of the ToadTog. Test the two sequences that
way.

A moderate fraction of macro, DSM and ToadTog problems are due to one of
two timing issues:

1)  The extender reduces (to the minimum value) the duration of signals which
are not the very last step in its macro buffer and signals which are processed
after the user has released the key that started the whole operation.
  If you suspect you have a duration problem, you should confirm it with two
tests. Put the single function on a pressable key and press and hold that
key. If that doesn't work, something more basic than a duration problem is
wrong. Put a macro or DSM on a pressable key that is just the problem
function followed by DEV_CANCEL. When you press that key, the function is
not last, so the duration will be minimal. If that introduces the failure
you know it's a duration problem (there are then a variety of approaches to
fixing it).

2)  The extender reduces the time between signals within any automated
sequence of signals. If functions work when manually sent in sequence, but
don't work when automatically sent in sequence, and you determine it's not a
duration problem, then it's time to try delays. Define a KeyMove for a
moderately long use of the pause protocol. Insert that before and/or after
the problem function(s) in your sequence. If that fixes it, you've confirmed
that it is a timing problem and you can then experiment to fine tune the
correction to fix the problem with minimum increase in the time it takes the
whole operation to complete.

Rarely, a device is sensitive to any signal at all right before or right
after its signal. In those cases, the best you can do is find the smallest
added delay that fixes the problem.

More often, a device just needs time to do the operation you gave it before
it is ready for the next. In a complex macro, you may have an alternative to
adding delay. If you're sending two commands to device A, then one command to
device B, try sending the command to device B in between the two commands to
device A. That probably takes one or two extra DEV_ commands beyond doing it 
the simple way, but probably takes less total execution time than simply 
adding delay.

                               URC-6960B00 and URC-9960B01 Extender Readme


N O T I C E
============

if you used the beta version of this extender you will find that your key assignments for Xshifted
and pseudo-device selection keys are no longer valid.  these keys were moved for version 0.35
of the extender.  This will require that you re-create your remote configurations.

This documentation is specific to extender v1.03 The version number ($0103) is stored at EEPROM[$FE/FF]

Revision history

	version		features/changes
	v 0.23		Initial  beta version
	v 0.35		Beta2 version, first version with version number in EEPROM, moved lots of keys around
	v 0.37		final realease - increased sizes of upgrade areas, shrunk advance code areas 
	v 1.00		upgrade release	- change to pause protocol for 100ms increments, updated documentation
	v 1.01		shrunk pause protocol, fix bug in LDKP protocol, updated LDKP documentation
                        add brightness control protocol
	v 1.02		fixed a couple of bugs, ability to disable HT screen, set screen on load to initial O_device
	v 1.03		moved/reduced code size (add 40+ bytes to Adv Code space)
			added screen-specific maps and images for RM support 
			distribute the URC-6960B00 and URC-9960B01 extender as a single package


BASIC FEATURES:
===============

  You can put a Macro or KeyMove on any (illuminated) key.
  You have room for lots more KeyMoves and Macros.
  You have more room for upgrades (significantly more in the 9960B01) than in the non-extended remote
  Macros can be Nested
  Macros are fast
  Very flexible device selection
  Improved (very different) Fav list processing
  Included protocols for Pause, Device-specific Macro, Long and Double Keypress and ToadTog
  Optional second shift key
  Configurable backlight timer in IR
  Configurable backlight button action in IR
  Configurable disable of backlight motion detection in IR
  Backlight brightness control via a special device/protocol
  Key remapping as in the non-extended remote is supported
  Automatic screen updating on specific keys as in the non-extended remote is supported
  Ability to disable HT screen 

 
  No Learned signal support
  No Scan support
  No direct keying of EFC codes on the remote
  No long-press-setup functions
  No modem download support


S P E C I A L  N O T E S:
=========================


REMAPPED KEYS:
==============

This extender  implements "key remapping" that allows an expanded set of keys based on 
the current screen.  For example, the "menu" key has a key value of $14 for most screens
but for the PVR-VOD screen "menu" has a value of $54.  This allows upgrades to assign two 
device commands to the same physical key based on the current screen.  The list of keys 
that are remapped are:

	orig	remap		screen
	------	-----------	---------------------------------------------
	Menu	VOD_Menu	2nd CBL screen (for PVR functions)
	Arrows	front,rear,	Audio screen
		center,test
	OK	Surround	Audio screen
	Digits	Tuner_xx	Audio screen

For the enhanced HT key processing, the keys that are remapped are assigned to their
non-remapped keysets (ie: Surround is considered part of the menu keyset)


Since the remapped key values occupy the same "block" of keys that the extender uses for 
Xshifted keys, these original keys cannot be Xshifted and the RDF restricts the use of 
these keys in the Xshifted state. (see the keys list EXCEL sheet for details)

Of special note is that versions prior to 1.79 of RM  gets slightly confused by this 
situation in two ways:  

First, because of the way that the keys are defined, RM does not show the remapped keys
in the layout screen.  To use the remapped keys as part of an upgrade you must define them 
using the layout screen.

Second, If you define  an upgrade onto a key that is remapped, you will also get a 
keymove in the keymove section as an Xshift key.  You can safely remove the keymove either 
prior to pasting into IR or  using the keymove tab in IR.   If you leave the keymove, the 
extender will process the key as a keymove and should not have any adverse effects other
than taking up space that you didn't need to use.

Version 1.79 of RM will fix/fixes this situation

Note:  the non-extended remote remapping of keys is done in the same way but 
       with no conflict with the Xshift block of keys.  

       The 9960B00EX2 extender does not implement this feature

  

INCLUDED DOCUMENTS
==================

  ReadMe.txt:

    (This file.) Describes overall features, usages and trouble shooting tips.

  Keys.XLS:

    An excel spreadsheet with all of the assigned keys and keycodes used in this extender
    and in the unextended remotes.  (both URC-9960B01 and URC-6960B00)

  Lit Keys Table.XLS

    an execl spreadsheet showing which keys are lit for which device/screen, useful when
    building upgrades to see if a key is lit for the device you are building

  x960ext.IR
 
    the extender in a pre-installed state into an IR file

  *.RDF 

    the RDF file, place in your RDF directory to enable IR and RM to use this extender

  IMAGES folder

    place the contents of this folder into the  images folder where your copy of RM is located



INSTALLATION AND ACTIVATION
===========================

The usual instructions do not apply to these extenders as Extinstall
is not compatible with the new remotes with $FF as the section terminators.  For this
reason (and until a new version of Extinstall is built) this extender is 
distributed ONLY as files readable by IR.  (6960B00ext.ir and 9960B01ext.ir)

If this situation changes I will re-distribute the extender in HEX form.

As a result, you will have to copy all of your keymoves, setup, devices and
macros from your old non-extended remote to these IR files 

When you upload this IR file to your remote for the first time, IR will give 
you an error message telling you that the signature does not match, you can 
ignore this.  You should not see this message again unless you do a 981 reset
to the remote.

The keymove to activate the extender is on the TV/power key.  The LED segment
below the device keys will blink twice to indicate that the extender has been 
activated.  I have seen occasions where the LED blinks differently, if this
happens to you you should remove the batteries and then re-activate the extender.

DEVICE SELECTION:
=================

There is no normal device selection.  There is no VPT.  There is no
Transport Punch Through.  There is no true Home Theater Mode. Home Theater 
button will place remote in the HT mode when an O_Device selection is 
on the HT button

Instead there is a device selection mechanism by key set that has a
superset of the power of all the above;  But you must define macros to use
and customize it.

The device keys and HT key have no built in meaning.  You must define
macros to have any device selection at all (default macros are included 
for all of the device keys and the HT keys, these can, of course, be
changed)

There are  commands that can be used in macros to control device
selection.  Each command specifies the key set and the Device Index that will
be used for keys in that set.  For example V_TV says the TV device will be
used for keys in the "Volume" set.

There are 6 Key sets: Menu, Channel, Volume, Transport, Other and
Temporary(X). (this is different than the URC-9960B00 which also had a 
PIP keyset, the PIP keyset is not supported in this extender.)

For the URC-6960B00 there are 6 Device indexes:

	CBL, TV, VCR, DVD, AUDIO and PVR

For the URC-9960B01 there are 8 Device Indexes: 

	CBL, TV, VCR, CD, DVD, AUDIO, AUX and PVR. 

There is one additional command X_Cancel which cancels the last temporary 
device selection. An X_Cancel is "implied" at the end of processing all pending
keys from the macro buffer.  (ie: you do not have to issue an X_Cancel at the end
of your macros)

To achieve simple device selection (no VPT, TPT or HT) you would put a 5
command macro on each device key, for example the TV device key would have
the macro:   M_TV; C_TV; V_TV; T_TV; O_TV.  The extender ships with these built-in
macros to make the first use of an extender easier.

To achieve VPT, replace the V_ command within the macro for each device
that should have VPT enabled with the command from the device to which VPT
should be set.  For example, to enable AUDIO VPT on your DVD, the DVD key
macro might be:  M_DVD; C_DVD; V_AUDIO; T_DVD; O_DVD

If you want full VPT (same V_ selection in all device selection macros) you
can save some macro memory by omitting all the V_ commands.  You can set the
initial V device using the IR general tab.  That remains as the V device as long as no V_
commands specify a different V_ device.

To achieve crude TPT (such as most of the UEIC remotes) replace the T_
command within the macro for each device that should have TPT enabled with
T_VCR.  For example, your TV key macro might be:
M_TV; C_TV; V_TV; T_VCR; O_TV

To achieve dynamic TPT (similar to the URC7800).  Omit the T_ command from
the macro for each non Transport device and include it in the macro for each
transport device (VCR, DVD etc.).  When you select a non transport device,
the T keys will all remain associated with whatever transport device was
most recently selected.

To achieve Home Theater, put a device selection macro on the Home Theater
key.  Include specific M_, C_, V_ and T_ commands to select your HT
settings.  To duplicate the UEIC version of HT mode, you can have any O_ command on
the HT macro so that the O keys are associated with whatever device they
are for.  (UEIC HT mode seems to support the Power key
only as a special macro.  With this extender the Power key is either an
ordinary macro or an ordinary O key, whichever you programmed it as).

Shifted keys all go into the key set containing their unshifted
counterpart.  For example SHIFT-Stop is in the T set.  Phantom keys are in
the O set.  Device keys are in the O set;  But most people will put macros
on device keys.  If a key is a macro, it doesn't matter which set it is in.
The set only matters for KeyMoves and for keys defined by setup code.

Key Illumination and Device Key Animation
-----------------------------------------

The 9960B01 and 6960B00 illuminate sets of keys that are available in 
the current device mode and animates the device key corresponding to the 
current device index.

In this extender, the O_ device selection commands decide what keys to
illuminate and to animate.  You can put a macro that includes an O_ command on
any button, however, the remote animates the device key which corresponds to
the O_ device index instead of the key that has the macro. The only exception 
to this is the HT key.  For HT you must have an O_ in the HT macro on the HT button



Note:  The HT key will select the HT screen until another O_dev command that is NOT 
in a macro on the HT key is used.  This allows for the HT screen to be used with more lit
keys for a theater setup.  A couple of comments on the HT key:

  1: The HT key is checked and the HT screen set if the HT button is pressed regardless
of if a macro is on the HT key.  This can be confusing for some users so this extender
version (1.02) has the ability in IR to change this.  Change the value for the HT Key from
$12 (decimal 18) to $00 in IR to disable the HT screen.  If you put a macro on the HT key, it
it will behave like any other key on the remote and the special HT screen handling will
not be enabled.

  2:  On the HT screen for the 9960B01 only, the OK button is remapped to "surround" ($67) while
all of the remaining "menu" keys remain in their non-remapped state.  This is done in the 
non-extended remote as well.  If you want to use the OK button, you will need a keymove for the
appropriate device from Surround to OK.



Illuminated key checking
------------------------

The extender checks to see if a key is "lit" on the current screen to see if the 
key should be processed.  IR and RM don't have any concept of "lit keys" so you could build
a keymove onto a key that is not lit and never be able to use it.  Pay attention to which
keys are lit for each screen.  For your reference a lit keys EXCEL table is included with the 
extender.  

The list of keys is different between the 6960 and 9960, the remapped keys are included
in the 9960 list.  The 9960 checks the lit keys list AFTER remapping has happened,
the 6960 checks BEFORE remapping.

(the lit keys checking is also done on the non-extended remote in the same way)


Automatic screen updating
-------------------------

As with the non-extended remote, special keys will scroll the screen to specific
screens related to that function.  For example, pressing the PVR-VOD key will scroll 
the screen to light the transport keys for a PVR regardless of the current screen.
(and change the keycode for menu as  described above) 

Note: The 9960B00EX2 extender does not implement this feature  

After the screen is scrolled, the extender will continue to process the keypress 
as a normal key.  Thus, you can place a command onto the key and it will be executed.  

The keys that will scroll screens are:

		Key		Device	new keys "lit"
		--------	-------	-------------------------

		PVR-VOD 	Cable	transport keys
		Menu		TV	arrow keys
		Guide		TV	arror keys
		LiveTV/PIP	TV	PIP keys
		Menu		VCR	arrow keys
		Guide		VCR	arrow keys
		Guide		AUD	arrow keys
		OK/Surround	AUD	surround keys
		Menu		AUD	arrow keys
		PVR-VOD		AUD	preset numbers

BRIGHTNESS CHANGE:
==================
This extender also includes a special protocol that allows you to change the backlight
brightness on the display.  This device and protocol is included by default in the 
extender (TV/1110 and Protocol 1FF) can be deleted if not being used to save space.

To enable, assign a keymove to TV/1110.  When this key is pressed, the screen will
change to one with only arrows.  Use the up key to increase brigthness, down to decrease.
When finished, press OK and the remote will be returned to its previous screen and 
the protocol exits. 


  
Temporary Device Selection:
---------------------------

Within a macro, you often want to issue a key to a specific device
regardless of the previous device selection and without disturbing that
previous device selection.  You use X_ commands to do that.  For example,
the sequence
X_TV; 0; 3
in a macro would send the 0 and 3 keys to the TV regardless of the previous
device selection.

The X_ selection is automatically canceled when the outermost macro (see
nested macros) completes.  If the above example were intended for use as a
top level macro, there would be no need for it to explicitly cancel its X_
command.  If the above example were in a general purpose macro that might
be called by other macros, you probably should change it to:
X_TV; 0; 3; X_Cancel

While an X_ command is active, it applies to all keys.  The usual division
into  Menu, Channel, Volume, Transport and Other doesn't apply.

NESTED MACROS:
==============

You can nest macros to any depth.  Any key that is a macro when used from
the keyboard is the same macro when used inside another macro.

This is very different from the base remote and from other extenders.  Pay
careful attention to this detail when converting a configuration for use
with this extender.  There is no protection from infinite loops when a macro
nests into itself.

Many people have used the fact that macros don't nest (in the basic remote)
for things like a Power macro that uses the normal Power key.  Find and
change anything like that in your configuration (see "Cloaking with Shift").

There is a 18 byte macro buffer, consistent with the size of the non-extended
remote.   That doesn't  set a limit on the total number of
commands executed by one macro (virtually unlimited).  It limits the number
of commands "pending" at any one moment.

To understand "pending" commands, imagine 4 macros, A, B, C, and D:

	A = B; C; D
	B = 1; 2; 3
	C = 4; B; 5; 6
	D = 7; 8; 9

when you press A, you get 1 2 3 4 1 2 3 5 6 7 8 9, which is 12 commands, but
in executing those 12 commands, there were never 12 commands "pending".
When the extender processes the first B there are 5 command pending:

	1; 2; 3; C; D;

Later it process the C and there are again 5 commands pending:

	4; B; 5; 6; D

When it processes the second B there are 6 commands pending

	1; 2; 3; 5; 6; D

The whole 12 commands are sent with a maximum of 6 ever pending.  You should
be able to design ridiculously long macros without ever hitting the limit of
19 pending commands.

FAST MACROS:
============

Both the hold time and the delay time for commands in a macro have been reduced.  I
think that is necessary to make macros useful.  There are situations in which
you need to add back some hold time or delay time.

For delay, you can use:

1)  For a very small delay, use a redundant device selection command.  If you
know that an X_ selection won't be in use at the relevant point in macro
execution, you can use a redundant X_Cancel as a tiny delay.  If you know or
use any other device selection, you can use it again as a delay.  For example,
if you want a delay between digits in the macro "C_TV; 0; 3" you could use
"C_TV; 0; C_TV; 3".

2) For a slightly longer delay, use an undefined key code. The actual amount
of delay will depend on the number of items in your KeyMove and Macro area.
For example, if you have no KeyMove or Macro for shift-X_Cancel, you could
use shift-X_Cancel as a delay.

3) For a long delay, use a KeyMove connected to the Pause protocol (TV/1104).
The hex command is the amount of delay from 01 (smallest) to FF.  The delay
is in units of about 0.1 seconds.

For adding back hold time, I haven't provided anything in this version of
the extender, except for the last step of a macro as follows.

HOLDING LAST STEP OF A MACRO:
=============================

If the last step of a macro transmits a signal, and you held down the
original key that started the macro through the entire macro execution,
the extender will continue the last signal while that button is held,
just as the remote normally does for a signal that is the only action of
a button.

This feature acts the same for ToadTogs and DSMs as for ordinary macros.
It acts the same for mini-macros (from a Fav list) as well, except that all
mini-macros are really exactly 5 commands long, rather than being 1 to 5
commands long as they seem.  IR.EXE pads any shorter mini-macros with NULL
commands to make them 5 commands long.  If a mini-macro is less than 5
commands, its last command is a NULL command, so holding the key won't make
a difference.  If you want holding the key to make a difference, try padding
the beginning or middle of the mini-macro with redundant device selection
commands rather than letting IR.EXE pad the end with NULL commands.

In rare cases, you want to defeat this feature and avoid having the last
step of a macro continued if the user holds the key.  You can most easily do
that by adding an X_ command to the end.

SHIFTED KEYS:
=============

Pressing the Setup key causes the next key to be "shifted".

The shift only affects the lookup of the key as a KeyMove or Macro.  If no
KeyMove or Macro is found for a shifted key, the remote then checks whether
the unshifted version of the key is defined by the setup code.

The Setup key only acts as a shift key when used from the keyboard.  When
used in a macro the Setup key is just an ordinary (O set) key.  When used
from the keyboard the Setup key is both a shift key and an ordinary key, so
you can get some confusing or interesting (depending on your intent)
behavior by defining a KeyMove or Macro for the Setup key.

To use a shifted key in a macro use the "Add Shift" option of IR;  Do not
try to make it shifted by preceding it with the Setup key.

Changing the Shift Key:
-----------------------

In the General/Other_Settings pane of IR.EXE you can configure shift to be
a different key or two keys.

"Shift Button Keycode" defines the primary shift key.  The value is displayed
as a decimal number.  The default is 2, which is the Setup key.  You can
change it to any key you prefer.  If you look up the keycode in KeyCodes.htm,
that value will be in hex.  You can type a hex value in the settings area by
prefixing it with "$".  IR will change it to the decimal value.  For example,
if you type the value in as $36 and IR shows it as 54.

"Alt Shift Button Keycode" defines an optional second shift key.  If that is
the same as the primary shift keycode then the extender will use only the
primary.  If it is a different valid code, that code will be a second shift.

"Alt Shift" selects whether the second shift key performs an xshift operation
or a ordinary (same as the first shift code) shift operation.  You can select
ordinary to have two shift keys that perform the same operation.  Using xshift
you can have up to three key moves on other keys by having an unshifted
keymove, a shifted keymove, and an xs-keymove.

The second shift key can be a code shifted by the first shift key.  In fact it
can be the first shift key shifted by itself.  For example, I set the first
shift keycode to $02 and the second one to $82 and selected "xshift".  Then if
I press P (setup) once, the next key is shifted;  If I press P twice, you get
the xs version of the next key;  If I press P three times, the next key is
back to normal.

Cloaking with Shift:
--------------------

If you want to define a macro for a key (such as Power) but also use that
key as defined by the setup code (probably in that macro) the trick is to
use the shifted version of the key.  For this to work, you must not define
a KeyMove for the shifted key (in the current device index) nor define a
macro for it.  Then put shift-Power inside the Power macro.  When the
extender fails to find a KeyMove or macro for shift-Power, it looks in the
setup code for a definition of Power and finds the one that you couldn't
access directly because the macro is in the way.

Shifted device selection commands:
----------------------------------

In other extenders shifted versions of the device selection commands (shift
M_VCR etc.) have been available as phantom codes, because they had no built in
meanings.  In this extender these commands cannot be shifted or Xshifted

KEY SETS:
=========

T  =  Fwd, Pause, Play, Record, Rew, Stop, SkipFwd, SkipBack, LiveTV
V  =  Vol+, Vol-, Mute
C  =  digits, Ch+, CH-, +100, Enter, Last, TV/VCR, Fav,
M  =  Down, Exit, Guide, Left, Menu, Info, Right, OK, Up
O  =  Power, M1-4, Setup, Scroll, Sleep, device keys, phantoms, PVR-VOD

  Note: the PIP keys are secondary meanings on the transport keys

FAV/SCAN:
=========

You can use IR to define a Fav list of up to 15 mini-macros of up to 5 keys
each.  IR handles all 15 mini-macros together as one line item in its Scan/Fav
tab.  Within that line item, the mini macros are delimited by "{pause}".  IR
also allows you to create additional whole Fav lists;  But the remote can't
use them.

   The extender operates the Fav list differently than the unextended remote
in three important aspects:

1) The extender executes just one mini-macro each time you press the Fav key
(advancing through them circularly).  The unextended remote will continue
executing the mini-macros with 3 second pauses in between until you press
another key to stop it.

2) The extender will switch the temporary device index to equal the Fav
device index whenever it starts a Fav mini-macro.  The unextended remote
only recognizes the Fav list if the device index already matches the Fav
device index.

3) The unextended remote will do a Scan operation instead of a Fav list
operation whenever the Fav key is used in a device index that doesn't match.
The extender will never do a Scan operation.  To have it do something other
than a Fav operation on certain device indexes, you must define a Key Move
for Fav for each such device index.  (The Key Move will only override the
Fav List if IR.EXE puts the key move earlier within the
KeyMove/Macro/FavList pool than it puts the FavList.)


BACKLIGHT AND SHIFT TIMER:
==========================

In the non-extended remote, the backlight comes on when you touch the remote 
or press a button.  It then stays on for up to five seconds.  (the non-extended
remote has limited ability to change this value through setup screens)

You can change that 5 second timer to another value in IR.  The value entered in
IR is roughly equal to the number of 100ms (0.1 sec) intervals.  So, if you wanted
the backlight timer to be 9 seconds, you would enter 90.  

The button action when pressed while the backlight is off can be configured on 
the General tab of IR. Scroll down to "First Key" and choose 
USE or IGNORE. Use will process the button immediately after turning the backlight 
on.  Ignore will discard the first button pressed  and only light the backlight
when the light is off just like the unextended remote.

You can disable the backlight turning on when the remote is moved by changing 
the option on the General Tab of IR.  Scroll down to the "Motion Sensor" and 
choose disable.

The extender also uses the same timer to cancel shift operations.  After
you release the shift key, you have only the length of time programmed as the
backlight timer to press the next key in order for that key to be shifted.

SPECIAL PROTOCOLS:
==================

This extender includes by default in the distributed IR file support for PAUSE,
ToadTog, LDKP and DSM special protocols. The special protocols are enabled in 
IR via the "special protocols" tab.  See additional documentation below on how to 
use these protocols.   



PAUSE Protocol:
===============

Included with the extender is the PAUSE protocol however this pause is different from
many of the other extenders.  The other extenders used the pause value as the number of
times through an internal delay loop in the remote.   This extender has tuned the PAUSE 
protocol such that each increment of the pause value is equal to 100ms of delay.  Thus,
you will likely find that pause times from other remotes will be very different from 
the times in this remote. 

Device Specific Macro:
======================

This special protocol is packaged as an upgrade protocol (1FC) and an upgrade
device (TV/1103) that are automatically installed when you install the extender.  
If you don't need this protocol and want to conserve upgrade memory, you can delete 
those upgrades.

This protocol allows you to build a macro that is only loaded and executed for 
a specific device and will allow you to build different macros on the same key  that
are executed for specific devices. 

To use DSM, use the Special Protocols tab and select DSM in the parameters pane.


Long/Double keypress:
=====================


This special protocol is packaged as an upgrade protocol (1F9)
and an upgrade device (TV/1106) that are automatically installed
when you install the extender.  If you don't need this protocol
and want to conserve upgrade memory you can delete those upgrades.

This special protocol allows you to execute either one of two key
sequences based on two different key press patterns:

  Long Key Press: Shorter vs. Longer than the specified duration.

  Double Key Press: Single vs. Double press.  (A double press
      is two consecutive key presses within the specified duration.)

Setup
------

In IR, Select the "Special Protocol" tab

1:  In the Bound Key section, select the bound device and key  

2:  In the Parameters pane, select LKP or DKP and the duration as 
    described above.

3:  In the Macro definition, add the keys for the Short/Long or
    single/double key presses.

Durations are expressed as digits 1 through 15 and have durations
of approximately:

      1 ... 0.76 sec
      2 ... 1.52 sec
      3 ... 2.28 sec
      4 ... 3.04 sec
      7 ... 5.32 sec
     11 ... 8.36 sec


ToadTOG - build toggles and discrete codes
==========================================

The 9960B01/6960B00 extender includes an enhanced replacement for the ToadTog
protocol.  It is packaged as an upgrade protocol (181) and an upgrade device
(VCR/1800) that are automatically installed when you install the extender. If 
you don't need a ToadTog protocol and want to conserve upgrade memory you
can delete those upgrades.

ToadTog lets you construct toggle functions from discrete functions, and/or
construct discrete functions from toggle functions, and/or track the state of
device toggles so that other functions may be sent differently depending on
that state.  It does this by testing the state of a toggle (see below) and then
sending a sequence of keystrokes depending on the state.  All of these are 
configurable through the IR special protocols tab.

There are 8 individually selectable toggles that retain state of the 
devices being controlled. You will need to use one of these for each toggle 
that you will be using in the remote.

Each ToadTog entry can test or change the state of the toggle in one of
four ways AFTER the command sequence has been loaded into the macro buffer
for processing.  These are:

    Toggle	toggle the state of the toggle bit
    test only	test only, do nothing to the state of the toggle bit
    force off	force the toggle to an off state
    force on	force the toggle to an on state

IR allows you to build your toggles or discrete commands by defining key
sequences that will be loaded and processed based on the state of the toggle
and then allowing you to set the state of the toggle.  The examples below show
how to build a discrete on/off from only a power toggle.  Similarl toggles can
be used to create a power toggle from discrete's, or a discrete device
selection command.  


Discrete on/off

In IR, you select a device and a keys for the new functions that you will
enable.  In this example we use DiscreteOff/DiscreteOn.  Next select an unused
toggle (toggle 1).  For the discrete off command, use the "force off" condition
that will tell the remote that after the command has executed the device will
be in the "off"state.   Next,define the sequence of keys that will execute with
the device in the "already on" state and in the "off-on" state.  If the device 
is already on, we want to send a "power toggle" command to the device to turn it 
off.  If the device is on the off state, we want to send no commands to it.

Similarly, for the discrete on, we will use the same toggle, select the
"force on" condition, and send a power toggle when the device is off and nothing
when it is on.  When you are finished you should see something like this:


VCR  DiscreteOff  ToadTog(1,Forceoff) on/off:power, already off: <blank> 
VCR  DiscreteOn   ToadTog(1,Forceon)  already on:<blank>, on/off:power



RDF FILES:
==========

The enclosed RDF files:

	"KAS0KASX (URC-9960B01 One For All Kameleon Extender).rdf"
	"OK60OK6X (URC-6960 One for All Kameleon Extender).rdf"

are  needed in the RDF directory for IR.EXE to edit an eeprom image of the extender
and for RM to build upgrades properly.

The above RDF as well as the original RDF files are required in the
directory where you run the ExtInstall program. 

  note: as of this release, extinstall does not work with these extenders

If there is an updated RDF you should probably use them instead of the RDF's 
included here.  

TROUBLE SHOOTING:
=================

This is a complicated extender that may still have some bugs in it, and it
lets you define very complex behaviours for your remote, which will probably
have errors on first try.

The major method of trouble shooting is to break complex operations down
into their parts and see if the parts work individually.

Example:  You have a macro that does some device selection and does two
phantom codes and each phantom code does a ToadTog and it doesn't work.
Assign those two ToadTogs to pressable keys (temporarily for trouble
shooting).  If necessary, define some simple macros to duplicate the
device selection of the complex macro.  Test the individual pieces of the
complex macro and see which work.

Example:  You have a ToadTog that doesn't work:  Make a simple macro or
DSM out of each command list of the ToadTog.  Test the two sequences that
way.

A moderate fraction of macro, DSM and ToadTog problems are due to one of
two timing issues:

1)  The extender reduces (to the minimum value) the duration of signals which
are not the very last step in its macro buffer and signals which are processed
after the user has released the key that started the whole operation.

If you suspect you have a duration problem, you should confirm it with two
tests.  Put the single function on a pressable key and press and hold that
key.  If that doesn't work, something more basic than a duration problem is
wrong.  Put a macro or DSM on a pressable key that is just the problem
function followed by an X_Cancel.  When you press that key, the function is
not last, so the duration will be minimum.  If that introduces the failure
you know it's a duration problem (there are then a variety of approaches to
fixing it).

2)  The extender reduces the time between signals within any automated
sequence of signals.  If functions work when manually sent in sequence, but
don't work when automatically sent in sequence, and you determine it's not a
duration problem, then it's time to try delays.  Define a KeyMove for a
moderately long use of the pause protocol.  Insert that before and/or after
the problem function(s) in your sequence.  If that fixes it, you've confirmed
that it is a timing problem and you can then experiment to fine tune the
correction to fix the problem with minimum increase in the time it takes the
whole operation to complete.

Rarely, a device is sensitive to any signal at all right before or right
after its signal.  In those cases, the best you can do is find the smallest
added delay that fixes the problem.

More often, a device just needs time to do the operation you gave it before
it is ready for the next.  In a complex macro, you may have an alternative to
adding delay.  If you're sending two commands to device A, then one command to
device B, try sending the command to device B in between the two commands to
device A.  That probably takes one or two extra X_ commands beyond doing it the
simple way, but probably takes less total execution time than simply adding
delay.

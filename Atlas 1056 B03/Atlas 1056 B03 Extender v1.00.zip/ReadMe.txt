Extender 1.00 for Atlas 1056 B03

This is a simple extender that adds the functionality of key moves and device specific macros (and multimacros on the multimacro keys) to the Atlas 1056 B03, a JP2 remote.  No existing functionality of the remote is changed, it just adds these new features.

The extender is installed by using the file "Atlas 1056 B03 Extender v1.00 Installer.rmir" in conjunction with RMIR 2.02 Beta 1.5t or later, as follows:

1.  Download your present configuration to RMIR and save it as a .rmir file.
2.  Copy the file "2010A9 (Atlas 1056 B03 Extender v1.00).rdf" to the folder containing your RDFs.
3.  Load "Atlas 1056 B03 Extender v1.00 Installer.rmir" into RMIR and upload it to the remote.
4.  Select TV and press the Record button.  The LED of the TV button should flash three times, with the first flash being a little longer than the others.  Four flashes means the upgrade has failed.
5.  Reload your saved configuration and upload it to the remote.  You will get a message saying "The signature of the attached remote does not match the signature you are trying to upload. ... How would you like to proceed?".  Press "Upload to the remote".
6.  Download the remote to RMIR and save it as a new .rmir file.  The installation is now complete.
7.  This step is optional.  If you have used RMIR to create one or more setups as .rmir files for your remote, you can avoid getting the mismatch message when you upload them by opening them with a text editor and replacing the first three entries under the [General] section, namely those starting Remote.name=, Remote.signature= and Remote.sigData=, with the corresponding entries in the .rmir file you saved at step 6.  Similarly replace the Remote.name= and Remote.signature= entries in any [DeviceUpgrade] sections in the file.  

You can now use RMIR to add keymoves and device specific macros to your configuration.  Device specific macros (DSMs) are added through the Special Functions tab.  There is only one Special Function, DSM.  Multimacros are entered by creating more than one macro on the same multimacro key (On Demand and the adjacent two keys with labels Help and Music) through either the Macro or Special Functions tabs.  If both a DSM and a (non-specific) macro are created on the same key, the non-specific macro applies only to those devices without a DSM.

The extender remains in place when you change batteries, and even survives a 981 Factory Reset.  If you want to remove it, repeat the installation procedure but press the Power button instead of Record at step 4.  You will get the signature mismatch message when you upload the installer to the remote in step 3, but just press "Upload to the remote".  No harm is done, but of course no benefit either, in installing it by pressing Record when it is already installed, or uninstalling it by pressing Power when it is already uninstalled.

The 6-character signature of the extended remote is 2010A9, distinct from the 201009 of the unextended remote, but the 5-digit signature you get by a 983 signature blink-back is still 20109.  The Raw Data tab of RMIR shows 2010A9 and also shows the extender version as 1.00.

Graham Dixon (mathdon)
5 June 2012

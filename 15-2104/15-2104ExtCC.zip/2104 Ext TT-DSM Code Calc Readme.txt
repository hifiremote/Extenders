2104 Extender - ToadTog and Device-Specific Macro Code Calculator
==================================================================

Use this spreadsheet to calculate the hex codes needed by the ToadTog and Device-Specific macro protocols. There is also a Breakdown mode that will decipher existing Hex Cmd code.


To use the ToadTog [Calculator] mode:
-------------------------------------

1) Select the desired [Toggle #]. There are 8 toggles (0-7) available for use with ToadTog.
2) Select the desired toggle [Condition]. These are detailed in the ToadTog Readme file.
3) Select from 0 to 7 ['ON'] sequence Buttons.
4) Select from 0 to 12 ['OFF'] sequence Buttons.

*Note: The total number of Buttons selected in the ['ON'] and ['OFF'] lists cannot exceed 12. If you specify 7 ['ON'] buttons, only 5 ['OFF'] buttons can be selected. The following table shows the maximum number of ['OFF'] buttons that can be specified based on the number of ['ON'] buttons:

 ON  OFF
---  ---
  0   12
  1   11
  2   10
  3    9
  4    8
  5    7
  6    6
  7    5

5) The [KeyMove 'Hex Cmd'] box will display the hex code required for the ToadTog KeyMove. You can copy the cell's contents to be pasted into IR's Key Moves tab (after clicking the [Add] button). Paste the data into the [EFC/Hex Cmd] box, making sure to select [Hex Cmd]. Specify the desired [Bound Key] information ([Device], [Key], and [Shift] state). Select VCR in the [Device Type] box and enter "1800" for the [Setup Code] (the ToadTog protocol uses the VCR/1800 setup code). When everything has been entered, click the [OK] button.

*Note: Due to a feature (or bug) in Excel's handling of copying data for pasting, IR's [EFC/Hex Cmd] box may contain some strange characters when you paste into it. This will not cause any problems as IR will strip the unnecessary characters when you click [OK].

6) Repeat steps 1 - 5 to calculate and setup more ToadTog KeyMoves.


To use the Device-Specific Macro [Calculator] mode:
---------------------------------------------------

1) Select from 1 to 13 buttons in the [Device-Specific Macro] drop-downs. The resulting 'Hex Cmd' data will be displayed in the [DSM 'Hex Cmd'] box.



Using the [Breakdown] feature:
------------------------------

Let's assume you've setup some ToadTog KeyMove's in your IR configuration. Day's, week's, or even month's go by and you can't remember exactly what the [EFC/Hex Cmd] code does. Simply click on the [Goto Breakdown...] button to display the Breakdown sheet. Next, go to IR and select the desired KeyMove in the table on IR's Key Moves tab and click the [Edit] button. Select (highlight) the entire contents of the [EFC/Hex Cmd] box, right-click on the selected text, and choose "Copy". Go back to the Breakdown sheet, right-click on the ['Hex Cmd' Code:] entry box, and choose "Paste". The Breakdown sheet will decipher the code and display the [Toggle #], [Condition], and all the appropriate Button data.

*Note: you can also type hex code directly into the ['Hex Cmd' Code:] entry box.

Happy Toggling!!!
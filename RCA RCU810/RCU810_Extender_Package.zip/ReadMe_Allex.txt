RCU810ex0

RCU810 extender, increases memory available for Key Moves and Macros, Allows Key Moves and Macros on any key


RCU810ex1

RCU810 extender v1.2: Increases memory available for KeyMoves and Macros. Allows KeyMoves and Macros on any Key. Dev selection only by macros. Has PushDev and PopDev. Standard VPT and transport punch through. Standard speed macros. 
  
	  	  	
RCU810ex2

RCU810 extender v2.2: Increases memory available for KeyMoves and Macros. Allows KeyMoves and Macros on any Key. Dev selection only by macros. Has PushDev and PopDev. Has Macro speedup and concatenation. Standard VPT and transport punch through.
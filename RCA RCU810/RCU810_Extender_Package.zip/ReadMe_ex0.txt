001)  This is the read.me file for rcu810ex, a functionality extender for the
RCU810 remote.

  If you don't like reading documentation, the quick version is:  Get a copy of
ExtInstall.zip and then follow instructions 203, 206 and 301 in this file.

  I am numbering the various sections of this read.me to make it easier for me
to cut and paste documentation as I release variants of extenders, and to make
it easier to direct people to answers if they ask questions I've already
answered.

101)  This extender lets you put Key Moves and Macros on any key, even the
code_search key or the lamp key.

102)  This extender disables all usual functions of the code_search key except
as a shift key.

105)  This extender increases the memory area for Key Moves and Macros to
appoximately 800 bytes (vs. the default size of 213 bytes).

106)  Macros are mixed in with Key Moves in the configuration.  In an
unextended remote the sequence doesn't matter.  If you have a macro and an
key move on the same key, the key move overrides the macro.
   In this extender, the sequence matters.  Whichever is first wins.  If you
want a key move to override a macro, you must make sure it is earlier in
the configuaration.  IR.EXE doesn't show you the relative position of key
moves and macros, so the process isn't obvious, but if you move a key move
within its list IR moves all the key moves before all the macros, so that
will restore the normal override behavior.

107)  This extender disables all learned keys.

110)  This extender disables the normal meaning of the device keys except
when executing a macro.  This lets you put key moves or Macros on device keys
that will execute without first switching to the associated device.  You
switch devices only with macros and you can put those macros on the device
keys and/or wherever else you like.  (The key moves or Macros you define for
the Device keys are only available when not in a macro).

111)  An unextended RCU810 executes the phantom key "Device" (after the
actual device switch) each time it processes a device key (in or out of
a macro).  In the unextended RCU810 that Device phantom key can only
be defined in the setup code (built in or upgrade) and cannot be
overidden with a Key Move or Macro.  This extender does not execute that
phantom key as part of processing the device key.  However, the default
macros for the device keys include that phantom key in order to come
close to duplicating the orriginal behavior.  With the extender you can
define a Key Move to override the Device phantom key.  You also can
remove it from a device key macro and do something else or nothing in
its place.

201)  The source code is included, with comments explaining how you might make
certain changes to the extender.  Experienced assembler programmers will also be
able to make other changes that I haven't explained.  If you make changes to the
source code, you will need my S3C8ASM assembler to convert the source code to a
hex file that can be installed.

202)  To install this extender you need my extender installer program.  It is
in ExtInstall.zip.  The installer merges information from the rcu810ex.hex file
with information from a .txt file saved by IR.EXE to produce a new .txt file in
the format used by IR.EXE.  The merged file will have Key Moves, Macros and
upgrades from the .txt file together with Key Moves, Macros, Upgrades and the
extender itself from the .hex file.  The .txt file can be one without an
extender or can be one with a prior version of this or another extender
installed.

203)  To install, put RDF files for both rcu810ex.hex and old.txt into the
current directory and type:

ExtInstall rcu810ex.hex old.txt new.txt

where "old.txt" is a file saved by IR.EXE from an RCU810 remote, and "new.txt"
will be created by the installer.

204)  In addition to the extender itself, rcu810ex.hex contains a protocol and
device upgrade for activating the extender.  It also contains a Key Move on
the POWER button in TV to activate that upgrade and protocol.  It also
contains 8 macros to define the 8 device keys as themselves (see 110).

205)  Put the included RDF file in the directory where you run IR.EXE, so that
IR.EXE will know the memory layout and special function names for this extender.
The included RDF file is for version 3.00 or later of IR.EXE

206)  After running the installer, use IR.EXE to examine and tweak the result.
You probably want to change the device key macros.

301)  After loading the eeprom image into the remote, or any other time the
remote is reset, you must activate the extender.  I set up the POWER key in
the TV device to activate the extender, if it isn't already active.  When the
extender is active, that definition of the power key is hidden.  TV is the
default device after an upload from IR, so you can just press POWER directly
after uploading from IR.

302)  The remote may reset when the batteries are interrupted, or when a
Key Move or the extender itself performs some wrong operation.  (Such as
a Key Move using a non installed setup code).  If the extender features
seem to be missing, try activating it again.

303)  Sometimes you want to deactivate the extender.  Normally the remote
is waiting in a super low power mode and simply removing a battery for 30
seconds won't reset it.  I just separate two batteries for a moment with
one hand while pressing a key with the other.  An instant of interrupted
power while a key is pressed is more likely to reset than 30 seconds of
interrupted power without a key press.

304)  While debugging protocols, I've sometimes (rarely) hung a remote
in low power mode with all keys disabled.  Rather than testing how long
it needs to sit without batteries to clear that, I take a battery out
and (with no need to wait or test whether it cleared) load a new eeprom
image with IR.EXE

410)  If you combine this extender with Nicola's selective macro protocol,
those macros must be in the old Key Move memory area, not the new one.  The
easiest way to put them there is to include the macros in the source code
of the extender (right after the "org 2A").
  Only those macros should be in the old Key Move area.  The key moves that
invoke the selective macro protocol should be in the new Key Move area.
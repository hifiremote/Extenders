This package is a combination of the three available extenders developed by johnsfine.  To use the extenders, try the following steps:

1.  Extract the zip file to an empty directory (e.g. C:\Extender).  We'll call this the extender directory.
2.  Load IR (4.01 at the time of writing)
3.  Go to File / Set RDF path to the extender directory.
4.  Go to File / New and select any of the four remote types. (Note that the "RCU810" selection has much less memory for key moves and macros.)
5.  Load your devices, protocols, key moves etc. (If you create macros, make sure that none are bound to any device keys)
6.  Select File / Save as and save your upgrade as "old.txt" in the extender directory
7.  Exit IR
8.  In windows explorer, run "Install_Allex.bat" in the extender directory.  This will create three new files in that directory:
new_ex0
new_ex1
new_ex2
These correspond to the following extenders:

RCU810ex0
RCU810 extender, increases memory available for Key Moves and Macros, Allows Key Moves and Macros on any key


RCU810ex1
RCU810 extender v1.2: Increases memory available for KeyMoves and Macros. Allows KeyMoves and Macros on any Key. Dev selection only by macros. Has PushDev and PopDev. Standard VPT and transport punch through. Standard speed macros. 
  
	  	  	
RCU810ex2
RCU810 extender v2.2: Increases memory available for KeyMoves and Macros. Allows KeyMoves and Macros on any Key. Dev selection only by macros. Has PushDev and PopDev. Has Macro speedup and concatenation. Standard VPT and transport punch through.

9.  Load any of these files into IR and upload the configuration to the remote.  
10.  IMPORTANT  Press TV and then POWER on the remote.  This will activate the extender.


All I've done here is combine all the extenders created by johnsfine with the updated RDF files from the 1.13 set of RDF files.  As well, I modified the batch files so that you can create all versions of the extenders at the same time and try each of them out.  There are other files in this package that describe each extender in more detail.  The Install810ex0, Install810ex1, and Install810ex2 batch files will convert the old.txt files for the specified extender.  The Buildex0, Buildex1 and Buildex2 batch files will create the .hex files from the .asm files for each extender (if you're feeling adventurous and want to modify the extenders).  You can always take any of the new_exX files, modify them, rename them as old.txt and run the batch file again to create a new set of extended profiles.
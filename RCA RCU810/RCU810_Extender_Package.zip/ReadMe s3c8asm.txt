Jun 24, 2003 release of S3C8asm.

To use:

S3C8ASM asm_file hex_file1 hex_file2 lst_file

You can have any subset of the three output formats generated.
If you want the first, or first+second, or first+second+third,
you can use the command line above with 2, 3 or 4 file names
in sequence.  If you want some other subset, you can use
command line switches for the three output formats in any order
in any subset (input file must still be first).

S3C8ASM asm_file -h hex_file1 -a hex_file2 -l lst_file

The file S3C8ASM.TXT contains templates for all the S3C8 instructions.
That file is read by the assembler each time it is run.  If you have
changed it, that file must be in the directory where you run the
assembler.  Otherwise, the EXE includes a copy of the default version,
which will be used if the file isn't found.

The ASM syntax is similar to the various S3C8 dissasemblers around
except:

1)  The condition code in a conditional JP or JR are part of the opcode,
rather than being an operand.

2)  The base register number in indexed addressing into register space
must be coded as a register, not as a #.  For example

	LD	W3,R4F[W0]	; get device code

3)  All numbers are in hex.  The leading # is optional.  The leading $
is optional.  The trailing H is optional.  Any of the following are
the same

	LD	R01, AB
	LD	R01, #AB
	LD	R01, #$AB
	LD	R01, ABH

4)  The doubling of an R or W to indicate use of a double register is
optional.  You cannot use a double R or double W to refer to a single
register, but you can use single or double to refer to a double
register.

5)  Label names are case sensitive, but everything else isn't.

6)  Rxx register uses are automatically changed to Wx when that can
reduce code size.  This feature is controlled by the W0 and W8
directives (see PanaCombo2x.asm example).  To turn this feature off
use an invalid (such as odd) value in W0 and W8 directives.

-----------------------------------------------------------------------

  I included a syntax sample S3C8inst.asm with a few pseudo ops up
front and one example each of every legal combination of an instruction
with an address mode (mainly auto generated from the S3C8ASM.TXT file).

  I also included two versions of the Panasonic Combo2 protocol as
examples.
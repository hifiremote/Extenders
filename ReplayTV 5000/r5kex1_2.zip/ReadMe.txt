BASIC FEATURES:
===============

  Multi-device support (12 devices)
  Macro support (fast and can be nested)
  Flexible VPT (Volume Punch Through)
  Built-in Device Specific Macro support (on first 8 devices)
  
  No long-press-setup functions

  This extender does NOT add the Advanced code key move feature


INSTALLATION AND ACTIVATION
===========================

  See documentation in Install.txt

DEVICE SELECTION:
=================

  Device selection is done by pseudo key commands.  You must define macros
to have any device selection at all.

  There are 37 commands that can be used in macros to control device
selection.  Each command specifies the key set and the Device Index
that willbe used for keys in that set.  For example V_TV says the TV
device will be used for keys in the "Volume" set.

  There are 3 Key sets: Volume, Other and Temporary(X).  There are 12 Device
Indexes: TV, REPLAY, CBL, VCR, CD, DVD, AUX and AUX2 - AUX6.  There is
one additional command X_Cancel.

  To achieve simple device selection (no VPT) you would put a 2 command
macro on each key which you want to use as device key.  For example,
if you want to make Shift-1 as the TV device key, it would have the macro:

V_TV; O_TV

  To achieve VPT, replace the V_ command within the macro for each device
that should have VPT enabled with the command from the device to which VPT
should be set.  For example, to enable AUX VPT on your DVD, the DVD key
macro might be:

V_AUX; O_DVD

  If you want full VPT (same V_ selection in all device selection macros) you
can save some macro memory by omitting most of the V_ commands.  Once you have
set a V_ device, it at remains as the V device as long as no other V_ commands
specify a different V_ device.


Temporary Device Selection:
---------------------------

  Within a macro, you often want to issue a key to a specific device
regardless of the previous device selection and without disturbing that
previous device selection.  You use X_ commands to do that.  For example,
the sequence
X_TV; 0; 3
in a macro would send the 0 and 3 keys to the TV regardless of the previous
device selection.

  The X_ selection is automatically canceled when the outermost macro (see
nested macros) completes.  If the above example were intended for use as a
top level macro, there would be no need for it to explicitly cancel its X_
command.  If the above example were in a general purpose macro that might
be called by other macros, you probably should change it to:
X_TV; 0; 3; X_Cancel

  While an X_ command is active, it applies to all keys.  The usual division
into Volume and Other doesn't apply.

NESTED MACROS:
==============

  You can nest macros to any depth.  Any key that is a macro when used from
the keyboard is the same macro when used inside a macro.

  This is very different from the base remote and from other extenders.  Pay
careful attention to this detail when converting a configuration for use
with this extender.  There is no protection from infinite loops when a macro
nests into itself.

  Many people have used the fact that macros don't nest (in the basic remote)
for things like a Power macro that uses the normal Power key.  Find and
change anything like that in your configuration (see "Cloaking with Shift").

  There is a 32 byte macro buffer (vs. the 15 byte buffer used by SelNestMac
on other remotes).  That doesn't change the limit on an individual macro
(still 15 commands) nor does it set a limit on the total number of
commands executed by one macro (virtually unlimited).  It limits the number
of commands "pending" at any one moment.

  To understand "pending" commands, imagine 4 macros, A, B, C, and D:
A = B; C; D
B = 1; 2; 3
C = 4; B; 5; 6
D = 7; 8; 9
when you press A, you get 1 2 3 4 1 2 3 5 6 7 8 9, which is 12 commands, but
in executing those 12 commands, there were never 12 commands "pending".
When the extender processes the first B there are 5 command pending:
1; 2; 3; C; D;
Later it process the C and there are again 5 commands pending:
4; B; 5; 6; D
When it processes the second B there are 6 commands pending
1; 2; 3; 5; 6; D
The whole 12 commands are sent with a maximum of 6 ever pending.  You should
be able to design ridiculously long macros without ever hitting the limit of
32 pending commands.

FAST MACROS:
============

  I reduced both the hold time and the delay time for commands in a macro.  I
think that is necessary to make macros useful.  There are situations in which
you need to add back some hold time or delay time.

  For delay, you can use:

1)  For a very small delay, use a redundant device selection command.  If you
know that an X_ selection won't be in use at the relevant point in macro
execution, you can use a redundant X_Cancel as a tiny delay.  If you know or
use any other device selection, you can use it again as a delay.  For example,
if you want a delay between digits in the macro "O_TV; 0; 3" you could use
"O_TV; 0; O_TV; 3".

2) For a slightly longer delay, use an undefined key code. The actual amount
of delay will depend on the number of items in your KeyMove and Macro area.
For example, if you have no KeyMove or Macro for shift-X_Cancel, you could
use shift-X_Cancel as a delay.

  For adding back hold time, I haven't provided anything in this version of
the extender, except for the last step of a macro.

HOLDING LAST STEP OF A MACRO:
=============================

  If the last step of a macro transmits a signal, and you held down the
original key that started the macro through the entire macro execution,
the extender will continue the last signal while that button is held,
just as the remote normally does for a signal that is the only action of
a button.

  This feature acts the same for DSMs as for ordinary macros.

  In rare cases, you want to defeat this feature and avoid having the last
step of a macro continued if the user holds the key.  You can most easily do
that by adding an X_ command to the end.

SHIFTED KEYS:
=============

   Pressing the TV key causes the next key to be "shifted".

   The shift only affects the lookup of the key as a KeyMove or Macro.  If no
KeyMove or Macro is found for a shifted key, the remote then checks whether
the unshifted version of the key is defined by the setup code.

   The TV key only acts as a shift key when used from the keyboard.  When
used in a macro the TV key is just an ordinary (O set) key.  When used
from the keyboard the TV key is both a shift key and an ordinary key, so
you can get some confusing or interesting (depending on your intent)
behavior by defining a KeyMove or Macro for the TV key.

   To use a shifted key in a macro use the "Add Shift" option of IR;  Do not
try to make it shifted by preceding it with the Setup key.


Power key and Zone key
----------------------

  The shifted Zone key and Power key share the same key code on this remote.
(i.e.: Shift-Zone = Power = Shift-Power)

  You should avoid using Shift-Zone and Shift-Power to avoid confusions.


Changing the Shift Key:
-----------------------

   In the General/Other_Settings/"Shift Button Keycode" section of IR.EXE
you can configure shift to be a different key.  The value is displayed
as a decimal number.  The default is 3, which is the TV key.  You can
change it to any key you prefer.  If you look up the keycode in KeyCodes.htm,
that value will be in hex.  You can type a hex value in the settings area by
prefixing it with "$".  IR will change it to the decimal value.  For example,
if you type the value in as $20 and IR shows it as 32.


Cloaking with Shift:
--------------------

   If you want to define a macro for a key (such as Power) but also use that
key as defined by the setup code (probably in that macro) the trick is to
use the shifted version of the key.  For this to work, you must not define
a KeyMove for the shifted key (in the current device index) nor define a
macro for it.  Then put shift-Power inside the Power macro.  When the
extender fails to find a KeyMove or macro for shift-Power, it looks in the
setup code for a definition of Power and finds the one that you couldn't
access directly because the macro is in the way.

KEY SETS:
=========

V  =  Vol+, Vol-, Mute
O  =  (all the other keys)

RDF FILES:
==========

  The enclosed RDF file "SBPASBa1 (Replay 5000 Extender1).rdf" is needed
in the directory where you run IR.EXE to edit an eeprom image of the
extender.

  The above rdf as well as some "Replay 5000" rdf files are required in the
directory where you run the ExtInstall program.

  In the past, as newer versions of IR.EXE have been released, they have been
bundled with updated versions of rdf files for various extenders.  If you use
this extender with a newer version of IR, it might include updates to the rdf
files that are included with this extender.  Such updates would have names
whose first 8 characters exactly match the first 8 characters of the rdf being
replaced (other parts of the name may be different).  If IR includes such
updates, you should probably use them instead of the rdfs included here.  If
IR is older than this extender or does not include such updates, then the
rdf files included hereshould be used.


TIPS
====

  The TV device type has very little keys in its key map.  Create a
device upgrade for your TV as a VCR device and use it instead of the
one built-in to the remote if you need more than the power and volume
functions.

  This remote doesn't support key moves even with this extender,
however, you can achieve the similar effect by DSMs.  Unlike real key
moves, the function must be assigned to a physical button in the key
map in a device upgrade which is tied to a device index.  Also, you
may need to include a device selection command (X_TV, etc.) in the DSM
if it is from other device index (perhaps this is almost always the
case, though).  This is somewhat cumbersome and less economical, but
at least you can do it when it is really necessary.

  If you create some "stub" device upgrade that are mainly to be used in
DSMs or macros, you may want to use AUX3 - 6 first.  (These device
indexes don't support DSMs, but you can use them in DSMs in any of the
first 8 device indexes, so it's a good idea to save more capable ones
for later needs.)


TROUBLE SHOOTING:
=================

  This is a complicated extender that may still have some bugs in it, and it
lets you define very complex behaviors for your remote, which will probably
have errors on first try.

  The major method of trouble shooting is to break complex operations down
into their parts and see if the parts work individually.

Example:  You have a macro that does some device selection and does two
phantom codes and each phantom code does a DSM and it doesn't work.
Assign those two DSMs to pressable keys (temporarily for trouble
shooting).  If necessary, define some simple macros to duplicate the
device selection of the complex macro.  Test the individual pieces of the
complex macro and see which work.

  A moderate fraction of macro, DSM and ToadTog problems are due to one of
two timing issues:

1)  The extender reduces (to the minimum value) the duration of signals which
are not the very last step in its macro buffer and signals which are processed
after the user has released the key that started the whole operation.
  If you suspect you have a duration problem, you should confirm it with two
tests.  Put the single function on a pressable key and press and hold that
key.  If that doesn't work, something more basic than a duration problem is
wrong.  Put a macro or DSM on a pressable key that is just the problem
function followed by an X_Cancel.  When you press that key, the function is
not last, so the duration will be minimum.  If that introduces the failure
you know it's a duration problem (there are then a variety of approaches to
fixing it).

2)  The extender reduces the time between signals within any automated
sequence of signals.  If functions work when manually sent in sequence, but
don't work when automatically sent in sequence, and you determine it's not a
duration problem, then it's time to try delays.  Define a KeyMove for a
moderately long use of the pause protocol.  Insert that before and/or after
the problem function(s) in your sequence.  If that fixes it, you've confirmed
that it is a timing problem and you can then experiment to fine tune the
correction to fix the problem with minimum increase in the time it takes the
whole operation to complete.
   Rarely, a device is sensitive to any signal at all right before or right
after its signal.  In those cases, the best you can do is find the smallest
added delay that fixes the problem.
   More often, a device just needs time to do the operation you gave it before
it is ready for the next.  In a complex macro, you may have an alternative to
adding delay.  If you're sending two commands to device A, then one command to
device B, try sending the command to device B in between the two commands to
device A.  That probably takes one or two extra X_ commands beyond doing it the
simple way, but probably takes less total execution time than simply adding
delay.
